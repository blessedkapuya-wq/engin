# THE QUIET SALES ENGINE · BiasharaBase.com

The official **Quiet Sales Engine** (No-Reels Text & DM System) for selling digital products, templates, and freelance services on **biasharabase.com**.

## What is Included
1. **Public Sales Page:** 5-question clarity overview, Who This Helps vs Who Should Not Buy, 7-Day Preview, Template Vault preview, Tanzanian TSh examples, Case Studies, Conversation Map, and Dual Payment Paths.
2. **Buyer Onboarding & 9-Tab Interactive Workspace:** Start Here (7-Day Plan), Build My Offer, What Should I Post?, 20-Template Vault, DM Scripts, Tanzanian Examples, Conversation Map, Case Studies, and Weekly Scorecard.
3. **Private Seller Admin Dashboard (`BB-ADMIN-2025`):** Manage customer access codes, search by email/order ID, revoke/restore codes, resend access emails, update pricing/mobile number (`0757 895 896` · `SARAH KAPUYA`), and connect Selar + Make.com + Supabase.
4. **Cloud Sync & Offline PWA Support:** Real-time Firestore database sync, Supabase verification mirror support, and printable PDF manual (`public/The-Quiet-Sales-Engine-8-Chapters.pdf`).

## Run Locally
```bash
npm install
npm run dev
```
Open `http://localhost:3000`.

## Deploy to Cloudflare Workers or Pages via GitHub
1. Unzip this folder and upload the **contents inside** directly to the root `/` of your GitHub repository (so `package.json`, `package-lock.json`, and `wrangler.jsonc` are at the top level).
2. **Recommended (Cloudflare Pages):** In Cloudflare Dashboard, go to **Workers & Pages → Create → Pages tab → Import an existing Git repository** with:
   - **Framework preset:** `Vite`
   - **Build command:** `npm run build`
   - **Build output directory:** `dist`
3. **If using Cloudflare Workers Builds (`npx wrangler deploy`):** Set:
   - **Build command:** `npm run build`
   - **Deploy command:** `npx wrangler deploy --assets ./dist`
   - **Root directory:** `/`
4. Click **Save and Deploy**.
5. Once live, open **Custom domains → Set up a custom domain** and enter `engine.biasharabase.com`.

---
© BiasharaBase (biasharabase.com). All rights reserved.

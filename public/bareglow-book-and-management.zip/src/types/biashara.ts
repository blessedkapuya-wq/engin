/**
 * TypeScript definitions for BiasharaBase.com Digital Product Guide
 * "POST THAT BIASHARA! - The No-Reels Sales Guide"
 * Designed according to the layout, typography, and structure of the reference PDF.
 */

export type PostTypeCategory = 
  | 'pitfall' 
  | 'question' 
  | 'process' 
  | 'opinion' 
  | 'ask' 
  | 'followup' 
  | 'review';

export interface DayPrompt {
  day: number;
  week: number;
  type: PostTypeCategory;
  typeName: string;
  tagCode: 'P' | 'Q' | 'W' | 'O' | 'A' | 'F' | 'R';
  lightTrackAction: 'POST' | 'REPLIES' | 'OFF' | 'SAME';
  template: string;
  example: string;
  noCameraImageIdea: string;
  userNotes?: string;
  isCompleted?: boolean;
}

export interface WeeklyMetricRow {
  week: number;
  posts: number;
  replies: number;
  convos: number;
  asks: number;
  oneThingToChange: string;
}

export interface BiasharaChapter {
  id: string;
  num: string;
  readTime: string;
  title: string;
  highlightWords: string[];
  subtitle: string;
  endOfChapterOutcome: string;
  corePoints: {
    num: string;
    headline: string;
    body: string;
  }[];
  interactiveToolType?: 'lane_builder' | 'reply_block' | 'weekly_ask_builder' | 'tracker' | 'post_crafter';
  doThisNow: {
    title: string;
    steps: string[];
  };
  founderQuote: {
    text: string;
    author: string;
  };
}

export interface BiasharaLaneLine {
  who: string;
  what: string;
  without: string;
}

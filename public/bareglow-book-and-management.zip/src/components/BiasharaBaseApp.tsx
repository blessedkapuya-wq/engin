import { useState, useEffect, useMemo } from 'react';
import { 
  BIASHARA_META, 
  BIASHARA_CHAPTERS, 
  DAY_PROMPTS, 
  PROMPT_BANK_EXTRAS, 
  INITIAL_METRIC_ROWS 
} from '../data/biasharaGuideData';
import { DayPrompt, WeeklyMetricRow, BiasharaLaneLine, PostTypeCategory } from '../types/biashara';
import { 
  BookOpen, 
  CheckCircle2, 
  Copy, 
  Check, 
  Sparkles, 
  Printer, 
  ArrowRight, 
  Clock, 
  Flame, 
  HelpCircle, 
  Share2, 
  Compass, 
  TrendingUp, 
  FileText,
  RotateCcw,
  Play,
  Pause,
  Sliders,
  ExternalLink
} from 'lucide-react';

interface BiasharaBaseAppProps {
  onBackToApp?: () => void;
}

export default function BiasharaBaseApp({ onBackToApp }: BiasharaBaseAppProps) {
  // Navigation tabs within the digital product
  const [activeTab, setActiveTab] = useState<'guide' | 'calendar' | 'tools' | 'tracker' | 'print'>('guide');
  const [selectedChapterIndex, setSelectedChapterIndex] = useState<number>(0);

  // 30-day action calendar state with localStorage persistence
  const [trackMode, setTrackMode] = useState<'daily' | 'light'>('daily');
  const [selectedWeekFilter, setSelectedWeekFilter] = useState<number | 'all'>('all');
  const [completedDays, setCompletedDays] = useState<Record<number, boolean>>(() => {
    try {
      const saved = localStorage.getItem('biashara_completed_days');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });
  const [selectedDayModal, setSelectedDayModal] = useState<DayPrompt | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Save completed days to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('biashara_completed_days', JSON.stringify(completedDays));
    } catch (e) {
      console.error(e);
    }
  }, [completedDays]);

  const toggleDayComplete = (day: number) => {
    setCompletedDays(prev => ({
      ...prev,
      [day]: !prev[day]
    }));
  };

  // Interactive Lane Line Generator State
  const [laneWho, setLaneWho] = useState<string>('side-hustlers and small shop owners');
  const [laneWhat, setLaneWhat] = useState<string>('get their first 10 paying customers from social media');
  const [laneWithout, setLaneWithout] = useState<string>('filming reels or spending money on ads');

  const generatedLaneLine = useMemo(() => {
    return `I help ${laneWho.trim() || '[WHO]'} get ${laneWhat.trim() || '[WHAT]'} without ${laneWithout.trim() || '[THE THING THEY HATE]'}.`;
  }, [laneWho, laneWhat, laneWithout]);

  // Interactive 5 Post Types Crafter State
  const [selectedPostType, setSelectedPostType] = useState<PostTypeCategory>('pitfall');
  const [postDraftParam1, setPostDraftParam1] = useState<string>('trying to be everywhere on 5 social networks');
  const [postDraftParam2, setPostDraftParam2] = useState<string>('pick ONE platform and master the 15-minute daily reply block');

  const craftedPostText = useMemo(() => {
    switch (selectedPostType) {
      case 'pitfall':
        return `The biggest mistake I see beginners make: ${postDraftParam1}.\n\nIt feels productive, but here is what actually happens: you burn out and get zero replies.\n\nInstead: ${postDraftParam2}.\n\nAre you guilty of this? Tell me below.`;
      case 'question':
        return `Quick question for anyone doing business online:\n\nWhen you think about ${postDraftParam1}, what is the single biggest headache keeping you awake at night?\n\nDrop your honest answer below. I'll reply to every single comment today.`;
      case 'process':
        return `Here is the exact unglamorous behind-the-scenes today:\n\nInstead of ${postDraftParam1}, here is how we handle it step-by-step: ${postDraftParam2}.\n\nWould you like the full breakdown template? Reply "TEMPLATE" below.`;
      case 'opinion':
        return `Unpopular opinion:\n\n${postDraftParam1} is complete nonsense for modern small businesses.\n\nHere is why: ${postDraftParam2}.\n\nAgree or disagree? Drop your thoughts.`;
      case 'ask':
        return `Weekly Ask:\n\nIf you want to solve ${postDraftParam1} this month, I have opened 3 private slots for ${postDraftParam2}.\n\nNo pitch calls. Just send me a direct message with "START" and I will share details.`;
      default:
        return '';
    }
  }, [selectedPostType, postDraftParam1, postDraftParam2]);

  // 15-minute reply block timer state
  const [timerSeconds, setTimerSeconds] = useState<number>(15 * 60);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds(sec => sec - 1);
      }, 1000);
    } else if (timerSeconds === 0) {
      setIsTimerRunning(false);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning, timerSeconds]);

  const formatTimer = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // 4-Number Weekly Tracker State with localStorage
  const [metricRows, setMetricRows] = useState<WeeklyMetricRow[]>(() => {
    try {
      const saved = localStorage.getItem('biashara_metric_rows');
      return saved ? JSON.parse(saved) : INITIAL_METRIC_ROWS;
    } catch {
      return INITIAL_METRIC_ROWS;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('biashara_metric_rows', JSON.stringify(metricRows));
    } catch (e) {
      console.error(e);
    }
  }, [metricRows]);

  const updateMetricRow = (weekNum: number, field: keyof WeeklyMetricRow, value: any) => {
    setMetricRows(prev => prev.map(row => {
      if (row.week === weekNum) {
        return { ...row, [field]: value };
      }
      return row;
    }));
  };

  const copyToClipboard = (text: string, keyId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(keyId);
    setTimeout(() => {
      setCopiedKey(null);
    }, 2000);
  };

  const completedCount = useMemo(() => {
    return Object.values(completedDays).filter(Boolean).length;
  }, [completedDays]);

  const filteredPrompts: DayPrompt[] = useMemo(() => {
    if (selectedWeekFilter === 'all') return DAY_PROMPTS;
    return DAY_PROMPTS.filter((p: DayPrompt) => p.week === selectedWeekFilter);
  }, [selectedWeekFilter]);

  const currentChapter = BIASHARA_CHAPTERS[selectedChapterIndex];

  return (
    <div className="min-h-screen bg-[#F5F5F3] text-stone-900 font-sans selection:bg-[#D2F803] selection:text-black">
      {/* Top Banner: BiasharaBase Digital Product Title Bar */}
      <div className="bg-[#111111] text-white border-b-2 border-black no-print">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#D2F803] text-black font-archivo font-black text-xl flex items-center justify-center shadow-md">
              B
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-archivo font-black text-sm sm:text-base tracking-wider uppercase text-white">
                  {BIASHARA_META.brand}
                </span>
                <span className="text-[11px] font-mono px-1.5 py-0.5 rounded bg-stone-800 text-[#D2F803] border border-stone-700">
                  {BIASHARA_META.domain}
                </span>
              </div>
              <p className="text-xs text-stone-400 font-medium">
                {BIASHARA_META.title} · {BIASHARA_META.subtitle}
              </p>
            </div>
          </div>

          {/* Action Links & Print */}
          <div className="flex items-center gap-2 flex-wrap text-xs">
            <span className="hidden md:inline text-stone-400">
              Completed: <strong className="text-[#D2F803]">{completedCount}/30 Days</strong>
            </span>

            <button
              onClick={() => {
                window.print();
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 font-bold transition cursor-pointer"
              title="Print or Save PDF"
            >
              <Printer className="w-3.5 h-3.5 text-[#D2F803]" />
              <span>Print / PDF</span>
            </button>

            {onBackToApp && (
              <button
                onClick={onBackToApp}
                className="px-3 py-1.5 rounded-lg bg-[#D2F803] hover:bg-[#bce002] text-black font-archivo font-extrabold transition cursor-pointer"
              >
                Return to Shop Book
              </button>
            )}
          </div>
        </div>

        {/* Product Navigation Subheader (Tabs) */}
        <div className="max-w-6xl mx-auto px-4 sm:px-6 border-t border-stone-800 flex items-center gap-1 sm:gap-2 overflow-x-auto py-2 scrollbar-none text-xs sm:text-sm font-archivo">
          <button
            onClick={() => setActiveTab('guide')}
            className={`px-3 py-1.5 rounded-lg font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'guide'
                ? 'bg-[#D2F803] text-black shadow-xs'
                : 'text-stone-300 hover:text-white hover:bg-stone-800'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>📖 8 Chapters Itinerary</span>
          </button>

          <button
            onClick={() => setActiveTab('calendar')}
            className={`px-3 py-1.5 rounded-lg font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'calendar'
                ? 'bg-[#D2F803] text-black shadow-xs'
                : 'text-stone-300 hover:text-white hover:bg-stone-800'
            }`}
          >
            <Flame className="w-4 h-4 text-orange-400" />
            <span>📅 30-Day Plan ({completedCount}/30)</span>
          </button>

          <button
            onClick={() => setActiveTab('tools')}
            className={`px-3 py-1.5 rounded-lg font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'tools'
                ? 'bg-[#D2F803] text-black shadow-xs'
                : 'text-stone-300 hover:text-white hover:bg-stone-800'
            }`}
          >
            <Sliders className="w-4 h-4 text-sky-400" />
            <span>🛠️ Interactive Toolkits</span>
          </button>

          <button
            onClick={() => setActiveTab('tracker')}
            className={`px-3 py-1.5 rounded-lg font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'tracker'
                ? 'bg-[#D2F803] text-black shadow-xs'
                : 'text-stone-300 hover:text-white hover:bg-stone-800'
            }`}
          >
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span>📊 4-Numbers Weekly Tracker</span>
          </button>

          <button
            onClick={() => setActiveTab('print')}
            className={`px-3 py-1.5 rounded-lg font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'print'
                ? 'bg-[#D2F803] text-black shadow-xs'
                : 'text-stone-300 hover:text-white hover:bg-stone-800'
            }`}
          >
            <FileText className="w-4 h-4 text-amber-300" />
            <span>📑 E-Book Document View</span>
          </button>
        </div>
      </div>

      {/* MAIN CONTAINER */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        
        {/* ========================================================= */}
        {/* TAB 1: 8 CHAPTERS GUIDE (FAITHFUL TO PDF SLIDES & SHEETS) */}
        {/* ========================================================= */}
        {activeTab === 'guide' && (
          <div className="space-y-8">
            {/* Hero Cover Card: Exact match to PDF Page 1 */}
            <div className="relative overflow-hidden rounded-3xl bg-[#111111] text-white p-6 sm:p-12 border-2 border-black shadow-xl">
              <div className="absolute top-0 right-0 w-96 h-96 bg-[#D2F803]/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
              
              <div className="relative z-10 max-w-3xl space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-stone-800 border border-stone-700 text-xs font-mono text-[#D2F803]">
                  <span>{BIASHARA_META.disclaimer}</span>
                </div>

                <h1 className="font-archivo text-3xl sm:text-5xl md:text-6xl font-black tracking-tight leading-[1.05] uppercase">
                  POST THAT <span className="bg-[#D2F803] text-black px-2 py-0.5 inline-block -rotate-1 rounded-sm shadow-xs">BIASHARA!</span>
                </h1>

                <p className="font-archivo text-lg sm:text-2xl font-bold text-stone-200 uppercase tracking-wide">
                  {BIASHARA_META.subtitle}
                </p>

                <p className="text-stone-300 text-sm sm:text-base leading-relaxed">
                  {BIASHARA_META.tagline}
                </p>

                {/* Read Tonight Callout Card */}
                <div className="mt-6 p-4 sm:p-6 rounded-2xl bg-stone-900/90 border border-stone-700 space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="font-archivo text-base sm:text-lg font-bold text-[#D2F803]">
                      {BIASHARA_META.readTonightText}
                    </span>
                    <span className="text-xs text-stone-400">· 25-minute total read</span>
                  </div>
                  <p className="text-xs sm:text-sm text-stone-300 whitespace-pre-line leading-relaxed">
                    {BIASHARA_META.readTonightDesc}
                  </p>
                </div>

                {/* Founder quote with Caveat handwriting */}
                <div className="pt-4 border-t border-stone-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="italic text-xs sm:text-sm text-stone-300 max-w-xl">
                    "{BIASHARA_META.founderQuote}"
                  </div>
                  <div className="font-handwriting text-2xl text-[#D2F803] whitespace-nowrap">
                    — {BIASHARA_META.founderName}
                  </div>
                </div>
              </div>
            </div>

            {/* Chapter Navigation Selector Bar */}
            <div className="bg-white rounded-2xl p-3 border-2 border-black shadow-md flex items-center gap-2 overflow-x-auto scrollbar-none">
              <span className="text-xs font-archivo font-black uppercase text-stone-400 px-2 shrink-0">
                Chapters:
              </span>
              {BIASHARA_CHAPTERS.map((ch, idx) => (
                <button
                  key={ch.id}
                  onClick={() => setSelectedChapterIndex(idx)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-archivo font-bold transition whitespace-nowrap cursor-pointer shrink-0 flex items-center gap-1.5 ${
                    selectedChapterIndex === idx
                      ? 'bg-black text-[#D2F803] shadow-xs'
                      : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                  }`}
                >
                  <span className="font-mono text-[11px] opacity-75">{ch.num}</span>
                  <span>{ch.title.split(' ')[0]}...</span>
                </button>
              ))}
            </div>

            {/* Selected Chapter Display (Faithfully following the PDF slides & sheets) */}
            <div className="space-y-6">
              {/* SLIDE 1: Chapter Dark Cover Slide */}
              <div className="bg-[#111111] text-white rounded-3xl p-6 sm:p-10 border-2 border-black shadow-lg relative overflow-hidden">
                <div className="flex items-center justify-between gap-4 border-b border-stone-800 pb-4 mb-6">
                  <div className="flex items-center gap-3">
                    <span className="font-archivo text-4xl sm:text-5xl font-black text-[#D2F803]">
                      {currentChapter.num}
                    </span>
                    <span className="text-xs font-mono px-2 py-1 rounded bg-stone-800 text-stone-300">
                      CHAPTER {currentChapter.num} OF 08
                    </span>
                  </div>
                  <div className="inline-flex items-center gap-1 text-xs font-mono text-[#D2F803]">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{currentChapter.readTime}</span>
                  </div>
                </div>

                <div className="space-y-4 max-w-3xl">
                  <h2 className="font-archivo text-2xl sm:text-4xl md:text-5xl font-black uppercase leading-tight">
                    {currentChapter.title}{' '}
                    <span className="bg-[#D2F803] text-black px-2 py-0.5 inline-block -rotate-1 rounded-sm shadow-xs">
                      {currentChapter.highlightWords.join(' ')}
                    </span>
                  </h2>

                  <p className="text-stone-300 text-sm sm:text-base leading-relaxed">
                    {currentChapter.subtitle}
                  </p>

                  {/* Outcome Box */}
                  <div className="mt-4 p-4 rounded-xl bg-stone-900 border border-stone-700 flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#D2F803] text-black font-bold flex items-center justify-center shrink-0">
                      ✓
                    </div>
                    <div>
                      <span className="text-[11px] font-mono uppercase text-stone-400 block">
                        End of Chapter Outcome:
                      </span>
                      <span className="text-sm font-archivo font-bold text-white">
                        {currentChapter.endOfChapterOutcome}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* SLIDE 2: Clean Light Content Worksheet Cards (2px solid black border, neo-brutalist) */}
              <div className="bg-white rounded-3xl p-6 sm:p-10 border-2 border-black shadow-md space-y-8">
                <div className="flex items-center justify-between border-b-2 border-stone-100 pb-4">
                  <h3 className="font-archivo text-lg sm:text-xl font-black uppercase tracking-tight text-stone-900">
                    Core Principles · Chapter {currentChapter.num}
                  </h3>
                  <span className="text-xs font-mono text-stone-500">
                    biasharabase.com / playbook
                  </span>
                </div>

                {/* Numbered Core Points */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {currentChapter.corePoints.map((point) => (
                    <div
                      key={point.num}
                      className="p-5 rounded-2xl bg-[#F9F9F7] border-2 border-black shadow-xs flex flex-col justify-between space-y-3"
                    >
                      <div className="flex items-center gap-2">
                        <span className="w-7 h-7 rounded-lg bg-black text-[#D2F803] font-archivo font-bold text-xs flex items-center justify-center shrink-0">
                          {point.num}
                        </span>
                        <h4 className="font-archivo text-base font-bold text-stone-900 leading-snug">
                          {point.headline}
                        </h4>
                      </div>
                      <p className="text-xs sm:text-sm text-stone-700 leading-relaxed">
                        {point.body}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Chapter Specific Interactive Widgets */}
                {currentChapter.interactiveToolType === 'lane_builder' && (
                  <div className="p-6 rounded-2xl bg-amber-50 border-2 border-black space-y-4">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-amber-600" />
                      <h4 className="font-archivo text-base font-black uppercase text-stone-900">
                        Interactive Lane Line Generator (Formula From PDF)
                      </h4>
                    </div>

                    <p className="text-xs text-stone-600">
                      Fill in the 3 components below to craft your irresistible bio sentence:
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="text-[11px] font-archivo font-bold uppercase text-stone-700 block mb-1">
                          1. WHO (Specific Customer)
                        </label>
                        <input
                          type="text"
                          value={laneWho}
                          onChange={(e) => setLaneWho(e.target.value)}
                          className="w-full px-3 py-2 text-xs rounded-xl border-2 border-black bg-white focus:outline-none focus:ring-2 focus:ring-[#D2F803]"
                          placeholder="e.g. side-hustlers and shop owners"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-archivo font-bold uppercase text-stone-700 block mb-1">
                          2. WHAT (Tangible Result)
                        </label>
                        <input
                          type="text"
                          value={laneWhat}
                          onChange={(e) => setLaneWhat(e.target.value)}
                          className="w-full px-3 py-2 text-xs rounded-xl border-2 border-black bg-white focus:outline-none focus:ring-2 focus:ring-[#D2F803]"
                          placeholder="e.g. get 10 paying customers"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-archivo font-bold uppercase text-stone-700 block mb-1">
                          3. WITHOUT (Thing They Hate)
                        </label>
                        <input
                          type="text"
                          value={laneWithout}
                          onChange={(e) => setLaneWithout(e.target.value)}
                          className="w-full px-3 py-2 text-xs rounded-xl border-2 border-black bg-white focus:outline-none focus:ring-2 focus:ring-[#D2F803]"
                          placeholder="e.g. filming reels or paying ads"
                        />
                      </div>
                    </div>

                    {/* Output Box */}
                    <div className="p-4 rounded-xl bg-white border-2 border-black flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
                      <div>
                        <span className="text-[10px] font-mono uppercase text-stone-500 block">
                          Your Finished Bio Sentence:
                        </span>
                        <p className="font-archivo text-sm font-bold text-stone-900 mt-0.5">
                          {generatedLaneLine}
                        </p>
                      </div>
                      <button
                        onClick={() => copyToClipboard(generatedLaneLine, 'lane_bio')}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-black text-[#D2F803] hover:bg-stone-800 text-xs font-archivo font-bold transition cursor-pointer shrink-0"
                      >
                        {copiedKey === 'lane_bio' ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Copied!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy for Bio</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                )}

                {currentChapter.interactiveToolType === 'reply_block' && (
                  <div className="p-6 rounded-2xl bg-stone-900 text-white border-2 border-black space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Clock className="w-5 h-5 text-[#D2F803]" />
                        <h4 className="font-archivo text-base font-black uppercase text-white">
                          The 15-Minute Daily Reply Timer
                        </h4>
                      </div>
                      <span className="text-2xl font-mono font-bold text-[#D2F803]">
                        {formatTimer(timerSeconds)}
                      </span>
                    </div>

                    <p className="text-xs text-stone-300">
                      The 5-5-5 Rule from Chapter 04: Spend 5 mins on accounts bigger than yours, 5 mins searching relevant topic tags, and 5 mins answering everyone who replied to you.
                    </p>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setIsTimerRunning(!isTimerRunning)}
                        className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#D2F803] text-black font-archivo font-bold text-xs hover:bg-[#bce002] transition cursor-pointer"
                      >
                        {isTimerRunning ? (
                          <>
                            <Pause className="w-4 h-4" />
                            <span>Pause Timer</span>
                          </>
                        ) : (
                          <>
                            <Play className="w-4 h-4" />
                            <span>Start 15-Min Sprint</span>
                          </>
                        )}
                      </button>
                      <button
                        onClick={() => {
                          setIsTimerRunning(false);
                          setTimerSeconds(15 * 60);
                        }}
                        className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-stone-800 text-stone-300 hover:text-white font-archivo font-bold text-xs transition cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Reset</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* "DO THIS NOW" Card matching PDF */}
                <div className="p-6 rounded-2xl bg-[#D2F803]/20 border-2 border-black space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="bg-black text-[#D2F803] px-2 py-0.5 rounded text-[11px] font-archivo font-black uppercase">
                      Do This Now
                    </span>
                    <h4 className="font-archivo text-base font-black text-stone-900">
                      {currentChapter.doThisNow.title}
                    </h4>
                  </div>
                  <ol className="space-y-2 list-decimal list-inside text-xs sm:text-sm text-stone-800 font-medium">
                    {currentChapter.doThisNow.steps.map((st, i) => (
                      <li key={i} className="leading-snug">
                        {st}
                      </li>
                    ))}
                  </ol>
                </div>

                {/* "FROM BIASHARABASE" Founder Callout Card */}
                <div className="p-5 rounded-2xl bg-[#111111] text-white border-2 border-black flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <span className="text-[10px] font-mono uppercase text-[#D2F803] block">
                      Note from the Playbook
                    </span>
                    <p className="text-xs sm:text-sm text-stone-300 italic leading-relaxed">
                      "{currentChapter.founderQuote.text}"
                    </p>
                  </div>
                  <div className="font-handwriting text-2xl text-[#D2F803] whitespace-nowrap shrink-0">
                    — {currentChapter.founderQuote.author}
                  </div>
                </div>

                {/* Bottom Navigation between Chapters */}
                <div className="pt-4 border-t-2 border-stone-100 flex items-center justify-between gap-4">
                  <button
                    disabled={selectedChapterIndex === 0}
                    onClick={() => setSelectedChapterIndex(prev => Math.max(0, prev - 1))}
                    className="px-4 py-2 rounded-xl border-2 border-black font-archivo text-xs font-bold disabled:opacity-30 disabled:cursor-not-allowed hover:bg-stone-100 transition cursor-pointer"
                  >
                    ← Previous Chapter
                  </button>

                  <span className="text-xs font-mono text-stone-500">
                    {selectedChapterIndex + 1} of {BIASHARA_CHAPTERS.length}
                  </span>

                  {selectedChapterIndex < BIASHARA_CHAPTERS.length - 1 ? (
                    <button
                      onClick={() => setSelectedChapterIndex(prev => Math.min(BIASHARA_CHAPTERS.length - 1, prev + 1))}
                      className="px-4 py-2 rounded-xl bg-black text-[#D2F803] font-archivo text-xs font-bold hover:bg-stone-800 transition cursor-pointer inline-flex items-center gap-1.5"
                    >
                      <span>Next Chapter</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  ) : (
                    <button
                      onClick={() => setActiveTab('calendar')}
                      className="px-4 py-2 rounded-xl bg-[#D2F803] text-black font-archivo text-xs font-black hover:bg-[#bce002] transition cursor-pointer inline-flex items-center gap-1.5"
                    >
                      <span>Go to 30-Day Plan</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 2: 30-DAY PLAN (DAILY TRACK VS LIGHT TRACK MATRIX)     */}
        {/* ========================================================= */}
        {activeTab === 'calendar' && (
          <div className="space-y-6">
            {/* Header & Track Selector */}
            <div className="bg-[#111111] text-white rounded-3xl p-6 sm:p-8 border-2 border-black shadow-lg space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full bg-stone-800 border border-stone-700 text-xs font-mono text-[#D2F803]">
                    <span>CHAPTER 07 · THE 30-DAY ACTION PLAN</span>
                  </div>
                  <h2 className="font-archivo text-2xl sm:text-3xl font-black uppercase tracking-tight text-white mt-1">
                    30 Days. Zero Guesswork.
                  </h2>
                </div>

                {/* Progress bar */}
                <div className="w-full sm:w-64 bg-stone-800 rounded-xl p-3 border border-stone-700">
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-stone-300">Progress:</span>
                    <span className="text-[#D2F803] font-bold">{completedCount} of 30 days ({Math.round((completedCount/30)*100)}%)</span>
                  </div>
                  <div className="w-full bg-stone-900 rounded-full h-2.5 overflow-hidden">
                    <div 
                      className="bg-[#D2F803] h-2.5 rounded-full transition-all duration-300"
                      style={{ width: `${(completedCount / 30) * 100}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Track Switcher */}
              <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                <span className="text-xs font-archivo font-bold text-stone-300 uppercase">
                  Select Your Track:
                </span>
                <div className="flex items-center p-1 rounded-xl bg-stone-900 border border-stone-700 w-full sm:w-auto">
                  <button
                    onClick={() => setTrackMode('daily')}
                    className={`flex-1 sm:flex-initial px-4 py-1.5 rounded-lg text-xs font-archivo font-bold transition cursor-pointer ${
                      trackMode === 'daily'
                        ? 'bg-[#D2F803] text-black shadow-xs'
                        : 'text-stone-400 hover:text-white'
                    }`}
                  >
                    🚀 Daily Track (~30 mins / day)
                  </button>
                  <button
                    onClick={() => setTrackMode('light')}
                    className={`flex-1 sm:flex-initial px-4 py-1.5 rounded-lg text-xs font-archivo font-bold transition cursor-pointer ${
                      trackMode === 'light'
                        ? 'bg-[#D2F803] text-black shadow-xs'
                        : 'text-stone-400 hover:text-white'
                    }`}
                  >
                    ⚡ Light Track (3 posts / week)
                  </button>
                </div>
              </div>
            </div>

            {/* Filter by Week */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
              <span className="text-xs font-archivo font-black uppercase text-stone-500 shrink-0">
                Filter Week:
              </span>
              {[
                { label: 'All 30 Days', val: 'all' as const },
                { label: 'Week 1 (Days 1–7)', val: 1 as const },
                { label: 'Week 2 (Days 8–14)', val: 2 as const },
                { label: 'Week 3 (Days 15–21)', val: 3 as const },
                { label: 'Week 4 (Days 22–30)', val: 4 as const }
              ].map(f => (
                <button
                  key={f.label}
                  onClick={() => setSelectedWeekFilter(f.val)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-archivo font-bold transition whitespace-nowrap cursor-pointer ${
                    selectedWeekFilter === f.val
                      ? 'bg-black text-[#D2F803]'
                      : 'bg-white border-2 border-black text-stone-800 hover:bg-stone-100'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {/* Prompt Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredPrompts.map((p: DayPrompt) => {
                const isChecked = !!completedDays[p.day];
                const isLightPost = p.lightTrackAction === 'POST' || p.lightTrackAction === 'SAME';

                return (
                  <div
                    key={p.day}
                    className={`rounded-2xl p-5 border-2 transition-all flex flex-col justify-between space-y-4 ${
                      isChecked
                        ? 'bg-emerald-50/50 border-emerald-600 shadow-xs'
                        : 'bg-white border-black shadow-md hover:-translate-y-0.5'
                    }`}
                  >
                    <div>
                      {/* Top Row: Day Pill, Type Tag, Track Action */}
                      <div className="flex items-center justify-between gap-2 mb-3">
                        <div className="flex items-center gap-1.5">
                          <span className="px-2 py-0.5 rounded-md bg-black text-[#D2F803] font-archivo font-black text-xs">
                            DAY {p.day.toString().padStart(2, '0')}
                          </span>
                          <span className="px-2 py-0.5 rounded-md bg-stone-100 text-stone-800 text-[11px] font-mono font-bold border border-stone-300">
                            W{p.week} · {p.typeName}
                          </span>
                        </div>

                        <button
                          onClick={() => toggleDayComplete(p.day)}
                          className={`w-6 h-6 rounded-full flex items-center justify-center transition cursor-pointer ${
                            isChecked
                              ? 'bg-emerald-600 text-white'
                              : 'border-2 border-stone-300 hover:border-black text-transparent'
                          }`}
                          title={isChecked ? 'Mark uncompleted' : 'Mark completed'}
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Track Indicator for Light Track */}
                      {trackMode === 'light' && (
                        <div className="mb-2">
                          {isLightPost ? (
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-900 border border-emerald-300 font-bold inline-block">
                              ⚡ Light Track: POST TODAY
                            </span>
                          ) : p.lightTrackAction === 'REPLIES' ? (
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 font-bold inline-block">
                              💬 Light Track: 15-MIN REPLIES ONLY
                            </span>
                          ) : (
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-stone-100 text-stone-600 border border-stone-300 font-bold inline-block">
                              ☕ Light Track: REST DAY
                            </span>
                          )}
                        </div>
                      )}

                      {/* Post Template Preview */}
                      <div className="space-y-2">
                        <span className="text-[10px] font-mono uppercase text-stone-500 font-bold block">
                          Template:
                        </span>
                        <p className="text-xs font-mono bg-stone-50 p-2.5 rounded-xl border border-stone-200 text-stone-800 whitespace-pre-line leading-relaxed">
                          {p.template}
                        </p>
                      </div>

                      {/* Real Example */}
                      <div className="mt-3 space-y-1">
                        <span className="text-[10px] font-mono uppercase text-stone-500 font-bold block">
                          Example from Playbook:
                        </span>
                        <p className="text-xs text-stone-700 italic border-l-2 border-[#D2F803] pl-2 leading-relaxed">
                          "{p.example}"
                        </p>
                      </div>

                      {/* No-Camera Image Tip */}
                      <div className="mt-3 p-2 rounded-lg bg-stone-100 text-[11px] text-stone-600 flex items-start gap-1.5">
                        <span className="text-xs">📸</span>
                        <span>
                          <strong>No-Camera visual:</strong> {p.noCameraImageIdea}
                        </span>
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="pt-3 border-t border-stone-100 flex items-center justify-between gap-2">
                      <button
                        onClick={() => copyToClipboard(p.template, `day_${p.day}`)}
                        className="inline-flex items-center gap-1 text-xs font-archivo font-bold text-stone-800 hover:text-black py-1 cursor-pointer"
                      >
                        {copiedKey === `day_${p.day}` ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                            <span className="text-emerald-700">Copied Template</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy Template</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => setSelectedDayModal(p)}
                        className="text-xs font-archivo font-bold text-stone-900 underline hover:text-[#D2F803] transition cursor-pointer"
                      >
                        Expand Details
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 3: INTERACTIVE TOOLKITS (CRAFTERS, FORMULAS & GENERATORS) */}
        {/* ========================================================= */}
        {activeTab === 'tools' && (
          <div className="space-y-8">
            {/* Tool 1: Five Post Types Crafter */}
            <div className="bg-white rounded-3xl p-6 sm:p-10 border-2 border-black shadow-md space-y-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b-2 border-stone-100 pb-4">
                <div>
                  <span className="text-[11px] font-mono uppercase text-stone-500 block">
                    Interactive Toolkit 01
                  </span>
                  <h3 className="font-archivo text-xl sm:text-2xl font-black uppercase text-stone-900">
                    Five Conversation Post Crafter
                  </h3>
                </div>
                <span className="px-3 py-1 rounded-full bg-[#D2F803] text-black font-archivo font-black text-xs">
                  Chapter 03 Engine
                </span>
              </div>

              {/* Post Type Selector Tabs */}
              <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
                {[
                  { id: 'pitfall' as const, label: '1. Pitfall Post', tag: 'P' },
                  { id: 'question' as const, label: '2. Low-Friction Question', tag: 'Q' },
                  { id: 'process' as const, label: '3. Process / BTS', tag: 'W' },
                  { id: 'opinion' as const, label: '4. Strong Opinion', tag: 'O' },
                  { id: 'ask' as const, label: '5. The Weekly Ask', tag: 'A' }
                ].map(pt => (
                  <button
                    key={pt.id}
                    onClick={() => {
                      setSelectedPostType(pt.id);
                      if (pt.id === 'pitfall') {
                        setPostDraftParam1('trying to be everywhere on 5 social networks');
                        setPostDraftParam2('pick ONE platform and master the 15-minute daily reply block');
                      } else if (pt.id === 'question') {
                        setPostDraftParam1('getting sales without expensive ads');
                        setPostDraftParam2('replying directly in DMs');
                      } else if (pt.id === 'process') {
                        setPostDraftParam1('hiring an expensive agency');
                        setPostDraftParam2('our 3-step customer follow-up protocol on WhatsApp');
                      } else if (pt.id === 'opinion') {
                        setPostDraftParam1('Posting 5 reels a day');
                        setPostDraftParam2('conversations and DMs are where 90% of actual transactions close');
                      } else if (pt.id === 'ask') {
                        setPostDraftParam1('inconsistent monthly cash flow');
                        setPostDraftParam2('our 30-day Social Selling Accelerator');
                      }
                    }}
                    className={`px-3 py-2 rounded-xl text-xs font-archivo font-bold transition whitespace-nowrap cursor-pointer ${
                      selectedPostType === pt.id
                        ? 'bg-black text-[#D2F803] shadow-xs'
                        : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                    }`}
                  >
                    {pt.label}
                  </button>
                ))}
              </div>

              {/* Form Input fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-archivo font-bold uppercase text-stone-800 block mb-1">
                    {selectedPostType === 'pitfall' && 'Common Mistake / Trap:'}
                    {selectedPostType === 'question' && 'Topic / Scenario:'}
                    {selectedPostType === 'process' && 'What You Avoided:'}
                    {selectedPostType === 'opinion' && 'Myth / Flawed Belief:'}
                    {selectedPostType === 'ask' && 'Problem Solved:'}
                  </label>
                  <input
                    type="text"
                    value={postDraftParam1}
                    onChange={(e) => setPostDraftParam1(e.target.value)}
                    className="w-full px-3 py-2.5 text-xs rounded-xl border-2 border-black bg-stone-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#D2F803]"
                  />
                </div>

                <div>
                  <label className="text-xs font-archivo font-bold uppercase text-stone-800 block mb-1">
                    {selectedPostType === 'pitfall' && 'The Better Alternative:'}
                    {selectedPostType === 'question' && 'Specific Focus:'}
                    {selectedPostType === 'process' && 'Your Real Working Method:'}
                    {selectedPostType === 'opinion' && 'Why You Disagree (Lived Proof):'}
                    {selectedPostType === 'ask' && 'Specific Offer & Call to Action:'}
                  </label>
                  <input
                    type="text"
                    value={postDraftParam2}
                    onChange={(e) => setPostDraftParam2(e.target.value)}
                    className="w-full px-3 py-2.5 text-xs rounded-xl border-2 border-black bg-stone-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#D2F803]"
                  />
                </div>
              </div>

              {/* Live Preview Box */}
              <div className="p-5 rounded-2xl bg-[#111111] text-white border-2 border-black space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono uppercase text-[#D2F803]">
                    Live Post Preview (Threads / Social Ready)
                  </span>
                  <button
                    onClick={() => copyToClipboard(craftedPostText, 'crafted_post')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#D2F803] text-black hover:bg-[#bce002] text-xs font-archivo font-bold transition cursor-pointer"
                  >
                    {copiedKey === 'crafted_post' ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Copied to Clipboard!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Finished Post</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="p-4 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 text-xs sm:text-sm font-sans whitespace-pre-line leading-relaxed">
                  {craftedPostText}
                </div>
              </div>
            </div>

            {/* Tool 2: The Extra 15 Prompt Bank */}
            <div className="bg-white rounded-3xl p-6 sm:p-10 border-2 border-black shadow-md space-y-6">
              <div className="flex items-center justify-between border-b-2 border-stone-100 pb-4">
                <div>
                  <span className="text-[11px] font-mono uppercase text-stone-500 block">
                    Bonus Prompt Vault
                  </span>
                  <h3 className="font-archivo text-xl sm:text-2xl font-black uppercase text-stone-900">
                    The 15 Extra Prompts for High-Engagement Days
                  </h3>
                </div>
                <span className="text-xs font-mono text-stone-500">
                  biasharabase.com vault
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {PROMPT_BANK_EXTRAS.map((extra, idx) => (
                  <div
                    key={extra.id}
                    className="p-4 rounded-2xl bg-[#F9F9F7] border-2 border-black flex flex-col justify-between space-y-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-black text-[#D2F803] font-bold">
                          PROMPT #{idx + 1} · {extra.category}
                        </span>
                      </div>
                      <p className="text-xs font-mono font-medium text-stone-900 pt-1">
                        {extra.prompt}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-stone-200">
                      <span className="text-[10px] text-stone-500 italic">
                        {extra.whyItWorks}
                      </span>
                      <button
                        onClick={() => copyToClipboard(extra.prompt, extra.id)}
                        className="text-xs font-archivo font-bold text-stone-900 hover:text-black inline-flex items-center gap-1 cursor-pointer"
                      >
                        {copiedKey === extra.id ? (
                          <span className="text-emerald-700 font-bold">Copied!</span>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 4: 4-NUMBERS WEEKLY TRACKER (INTERACTIVE METRIC LOG)  */}
        {/* ========================================================= */}
        {activeTab === 'tracker' && (
          <div className="space-y-6">
            <div className="bg-[#111111] text-white rounded-3xl p-6 sm:p-8 border-2 border-black shadow-lg space-y-3">
              <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full bg-stone-800 border border-stone-700 text-xs font-mono text-[#D2F803]">
                <span>CHAPTER 08 · FOUR NUMBERS TO TRACK</span>
              </div>
              <h2 className="font-archivo text-2xl sm:text-3xl font-black uppercase text-white">
                Ignore Vanity Metrics. Track These Four.
              </h2>
              <p className="text-xs sm:text-sm text-stone-300 max-w-2xl leading-relaxed">
                Follower count doesn't pay for rent, inventory or feed. Track these 4 operational numbers every Sunday. If conversations and asks are happening, sales are happening.
              </p>
            </div>

            {/* Tracker Table */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-black shadow-md overflow-x-auto">
              <table className="w-full text-left text-xs font-mono min-w-[600px]">
                <thead>
                  <tr className="border-b-2 border-black text-stone-700 font-archivo font-bold text-xs">
                    <th className="py-3 px-2">WEEK</th>
                    <th className="py-3 px-2">1. POSTS</th>
                    <th className="py-3 px-2">2. REPLIES</th>
                    <th className="py-3 px-2">3. CONVOS</th>
                    <th className="py-3 px-2">4. ASKS</th>
                    <th className="py-3 px-2">ONE THING TO CHANGE NEXT WEEK</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200">
                  {metricRows.map((row) => (
                    <tr key={row.week} className="hover:bg-stone-50">
                      <td className="py-3 px-2 font-archivo font-black text-sm">
                        Week {row.week}
                      </td>

                      <td className="py-3 px-2">
                        <input
                          type="number"
                          value={row.posts}
                          onChange={(e) => updateMetricRow(row.week, 'posts', Number(e.target.value) || 0)}
                          className="w-16 px-2 py-1 rounded-lg border border-stone-300 font-mono text-center font-bold"
                          min="0"
                        />
                      </td>

                      <td className="py-3 px-2">
                        <input
                          type="number"
                          value={row.replies}
                          onChange={(e) => updateMetricRow(row.week, 'replies', Number(e.target.value) || 0)}
                          className="w-16 px-2 py-1 rounded-lg border border-stone-300 font-mono text-center font-bold"
                          min="0"
                        />
                      </td>

                      <td className="py-3 px-2">
                        <input
                          type="number"
                          value={row.convos}
                          onChange={(e) => updateMetricRow(row.week, 'convos', Number(e.target.value) || 0)}
                          className="w-16 px-2 py-1 rounded-lg border border-stone-300 font-mono text-center font-bold"
                          min="0"
                        />
                      </td>

                      <td className="py-3 px-2">
                        <input
                          type="number"
                          value={row.asks}
                          onChange={(e) => updateMetricRow(row.week, 'asks', Number(e.target.value) || 0)}
                          className="w-16 px-2 py-1 rounded-lg border border-stone-300 font-mono text-center font-bold"
                          min="0"
                        />
                      </td>

                      <td className="py-3 px-2">
                        <input
                          type="text"
                          value={row.oneThingToChange}
                          onChange={(e) => updateMetricRow(row.week, 'oneThingToChange', e.target.value)}
                          className="w-full px-2 py-1 rounded-lg border border-stone-300 text-xs font-sans"
                          placeholder="e.g. Reply 10 mins earlier in the morning"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Total Calculation Row */}
              <div className="mt-6 pt-4 border-t-2 border-black flex flex-wrap items-center justify-between gap-4 text-xs font-archivo font-bold">
                <div className="flex items-center gap-4">
                  <span className="text-stone-500 uppercase">30-Day Totals:</span>
                  <span className="px-2.5 py-1 rounded-lg bg-stone-100 border border-stone-300">
                    Posts: <strong className="text-black">{metricRows.reduce((a, b) => a + b.posts, 0)}</strong>
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-stone-100 border border-stone-300">
                    Replies: <strong className="text-black">{metricRows.reduce((a, b) => a + b.replies, 0)}</strong>
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-[#D2F803] text-black">
                    Convos Started: <strong>{metricRows.reduce((a, b) => a + b.convos, 0)}</strong>
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-stone-900 text-white">
                    Direct Asks: <strong>{metricRows.reduce((a, b) => a + b.asks, 0)}</strong>
                  </span>
                </div>

                <button
                  onClick={() => {
                    if (confirm('Reset your 4-number tracker back to initial state?')) {
                      setMetricRows(INITIAL_METRIC_ROWS);
                    }
                  }}
                  className="text-stone-500 hover:text-red-600 transition text-[11px] underline cursor-pointer"
                >
                  Reset Tracker
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 5: E-BOOK DOCUMENT VIEW (PRINT-READY COMPACT FORMAT)   */}
        {/* ========================================================= */}
        {activeTab === 'print' && (
          <div className="bg-white rounded-3xl p-6 sm:p-12 border-2 border-black shadow-lg space-y-12">
            <div className="text-center space-y-2 border-b-2 border-black pb-8">
              <span className="font-mono text-xs text-stone-500 uppercase tracking-widest block">
                biasharabase.com · digital product edition
              </span>
              <h1 className="font-archivo text-4xl sm:text-5xl font-black uppercase text-stone-900">
                POST THAT <span className="bg-[#D2F803] text-black px-2 py-0.5 inline-block -rotate-1">BIASHARA!</span>
              </h1>
              <p className="font-archivo text-lg font-bold text-stone-700 uppercase">
                {BIASHARA_META.subtitle}
              </p>
              <p className="text-xs text-stone-500 max-w-xl mx-auto">
                {BIASHARA_META.tagline}
              </p>
            </div>

            {/* All Chapters Sequenced */}
            <div className="space-y-10">
              {BIASHARA_CHAPTERS.map((ch) => (
                <div key={ch.id} className="border-b-2 border-stone-200 pb-8 space-y-4">
                  <div className="flex items-center gap-3">
                    <span className="font-archivo text-3xl font-black text-black">
                      {ch.num}.
                    </span>
                    <h2 className="font-archivo text-xl font-black uppercase text-stone-900">
                      {ch.title} {ch.highlightWords.join(' ')}
                    </h2>
                    <span className="text-[11px] font-mono text-stone-500 ml-auto">
                      {ch.readTime}
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-stone-700 italic">
                    {ch.subtitle}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    {ch.corePoints.map((pt) => (
                      <div key={pt.num} className="p-3 rounded-xl bg-stone-50 border border-stone-300">
                        <strong className="font-archivo text-xs text-stone-900 block mb-1">
                          {pt.num}. {pt.headline}
                        </strong>
                        <p className="text-[11px] text-stone-600 leading-relaxed">
                          {pt.body}
                        </p>
                      </div>
                    ))}
                  </div>

                  <div className="p-3 rounded-xl bg-amber-50 border border-amber-300 text-xs">
                    <strong className="font-archivo text-amber-950 uppercase block mb-1">
                      Action Item: {ch.doThisNow.title}
                    </strong>
                    <ul className="list-disc list-inside space-y-0.5 text-stone-700">
                      {ch.doThisNow.steps.map((st, i) => (
                        <li key={i}>{st}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>

            {/* Print button footer */}
            <div className="text-center pt-4 no-print">
              <button
                onClick={() => window.print()}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-black text-[#D2F803] font-archivo font-extrabold text-sm hover:bg-stone-800 transition cursor-pointer shadow-md"
              >
                <Printer className="w-4 h-4" />
                <span>Print or Save Complete PDF</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* MODAL: EXPANDED DAY PROMPT DETAILS */}
      {selectedDayModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 border-2 border-black shadow-2xl space-y-5 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b-2 border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-lg bg-black text-[#D2F803] font-archivo font-black text-xs">
                  DAY {selectedDayModal.day}
                </span>
                <span className="font-archivo font-bold text-sm text-stone-900">
                  {selectedDayModal.typeName}
                </span>
              </div>
              <button
                onClick={() => setSelectedDayModal(null)}
                className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <span className="text-[10px] font-mono uppercase text-stone-500 font-bold block mb-1">
                  Ready-to-use Template:
                </span>
                <div className="p-3 rounded-xl bg-stone-50 border border-stone-200 font-mono text-xs text-stone-900 whitespace-pre-line leading-relaxed">
                  {selectedDayModal.template}
                </div>
              </div>

              <div>
                <span className="text-[10px] font-mono uppercase text-stone-500 font-bold block mb-1">
                  Example from BiasharaBase:
                </span>
                <p className="text-xs text-stone-700 italic border-l-2 border-[#D2F803] pl-3 leading-relaxed">
                  "{selectedDayModal.example}"
                </p>
              </div>

              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-950">
                <strong>📸 No-Camera Image Tip:</strong> {selectedDayModal.noCameraImageIdea}
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between gap-3 border-t border-stone-100">
              <button
                onClick={() => toggleDayComplete(selectedDayModal.day)}
                className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-archivo font-bold transition cursor-pointer ${
                  completedDays[selectedDayModal.day]
                    ? 'bg-emerald-600 text-white'
                    : 'bg-stone-100 hover:bg-stone-200 text-stone-800'
                }`}
              >
                <Check className="w-3.5 h-3.5" />
                <span>
                  {completedDays[selectedDayModal.day] ? 'Completed!' : 'Mark as Done'}
                </span>
              </button>

              <button
                onClick={() => copyToClipboard(selectedDayModal.template, `modal_${selectedDayModal.day}`)}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-black text-[#D2F803] hover:bg-stone-800 text-xs font-archivo font-bold transition cursor-pointer"
              >
                {copiedKey === `modal_${selectedDayModal.day}` ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Template</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

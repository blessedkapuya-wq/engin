import { BiasharaChapter, DayPrompt, WeeklyMetricRow } from '../types/biashara';

export const BIASHARA_META = {
  brand: 'biashara base',
  domain: 'biasharabase.com',
  handle: '@biasharabase',
  title: 'POST THAT BIASHARA!',
  subtitle: 'THE NO-REELS COMMERCE & SOCIAL SELLING GUIDE',
  tagline: 'No reels. No dancing. What to post on Threads, WhatsApp & Social so people start talking to you and buying.',
  stats: '8 short chapters · 30-day plan in two tracks · Interactive prompt builder',
  disclaimer: 'No reels were filmed in the making of this guide.',
  readTonightText: 'Read it tonight. Post tomorrow.',
  readTonightDesc: 'This guide is short on purpose. You can read it in about 25 minutes, and the 30-day plan starts tomorrow.\n\nNo reels. No dancing. No face on camera. Just text posts, real replies and one honest ask a week.\n\nChapter 7 has two tracks: about 30 minutes a day, or about 2 hours a week when life gets busy. Pick one. You can switch.',
  founderQuote: 'I lost thousands of dollars to fake "promoters", expensive ad agencies and scam courses before anything worked. This is the guide I wish someone had handed me first. No income promises. Just what I\'d do if I started again tomorrow.',
  founderName: 'BiasharaBase Team'
};

export const BIASHARA_CHAPTERS: BiasharaChapter[] = [
  {
    id: 'ch01',
    num: '01',
    readTime: 'ABOUT 4 MIN',
    title: 'Why your posts get',
    highlightWords: ['crickets.'],
    subtitle: "You're not bad at this. You're posting into a room where nobody knows you yet. Here's how modern social algorithms treat small business accounts, and what to do about it.",
    endOfChapterOutcome: 'One real reply under a post in your lane.',
    corePoints: [
      {
        num: '01',
        headline: 'Conversations beat announcements',
        body: 'Most beginner posts are boring announcements: a new blog post, a new stock arrival, a new link. Nobody owes an announcement a reply, so most get zero. A conversation post gives people something easy to answer.'
      },
      {
        num: '02',
        headline: 'Replies are your biggest lever',
        body: 'Almost half of views on social platforms come from replies. Studies show +42% average engagement when business owners reply to comments under their own posts and under bigger creators.'
      },
      {
        num: '03',
        headline: 'Links go in your bio or first reply',
        body: 'Keep the main post for the conversation. Algorithms suppress posts with external links. People who want more will tap your bio link or look at your first comment.'
      },
      {
        num: '04',
        headline: 'Images often beat plain text',
        body: 'Simple no-camera images beat text-only posts again and again: a screenshot of a customer DM, a note app screenshot, or a sticky note on your desk.'
      },
      {
        num: '05',
        headline: 'Tags and Communities reach strangers',
        body: 'Add one relevant topic tag (#smallbusiness, #poultry, #sidehustle) to meet people who care about your topic. Tags connect you with buyers outside your follower circle.'
      }
    ],
    interactiveToolType: 'reply_block',
    doThisNow: {
      title: 'Leave one real reply.',
      steps: [
        'Find a post in your lane from an account bigger than yours.',
        'Reply with something real: a tip, a question, or your own lived experience. Never write "great post!!".',
        'Come back in an hour and answer anyone who replied to you.'
      ]
    },
    founderQuote: {
      text: 'When I started selling online, I spent my first two weeks replying to people as much as posting. The more I replied with genuine insight, the more customers tapped my bio and asked about my products. That is when it clicked.',
      author: 'BiasharaBase'
    }
  },
  {
    id: 'ch02',
    num: '02',
    readTime: 'ABOUT 3 MIN',
    title: 'Pick your lane in',
    highlightWords: ['one sentence.'],
    subtitle: 'People only follow accounts that are clearly for them. One sentence tells them whether you are worth following.',
    endOfChapterOutcome: 'Your lane line, written and placed in your bio tonight.',
    corePoints: [
      {
        num: '01',
        headline: 'Who you help',
        body: 'One specific kind of person, not "everyone" or "all businesses". The narrower your focus, the faster you get traction.'
      },
      {
        num: '02',
        headline: 'What you help them do',
        body: 'One tangible, desirable result they actually want to wake up and buy.'
      },
      {
        num: '03',
        headline: "What they don't have to do",
        body: "The exact thing they hate, dread, or are sick and tired of doing (e.g. dancing on video, quitting their job, paying for expensive ads)."
      }
    ],
    interactiveToolType: 'lane_builder',
    doThisNow: {
      title: 'Put it in your bio tonight.',
      steps: [
        'Write your lane line with the formula: I help [WHO] get [WHAT] without [THE THING THEY HATE].',
        'Read it out loud. If it sounds like an AI robot wrote it, rewrite it the way you would say it over coffee to a friend.',
        'Put it in your Threads, WhatsApp Business, and Instagram bio tonight.'
      ]
    },
    founderQuote: {
      text: 'Picking one lane feels like shutting doors. It isn\'t. When a stranger can tell in two seconds that you are for them, they follow and buy. When they can\'t, they scroll past. Narrow is not small.',
      author: 'BiasharaBase'
    }
  },
  {
    id: 'ch03',
    num: '03',
    readTime: 'ABOUT 6 MIN',
    title: 'Five post types that',
    highlightWords: ['start conversations.'],
    subtitle: 'Every single post you write from here on is one of these five. Each one gives your ideal customer a natural reason to reply and buy.',
    endOfChapterOutcome: "Tomorrow's pitfall story, written and ready to post.",
    corePoints: [
      {
        num: '01',
        headline: 'The Pitfall Story (Tell them what you got wrong)',
        body: 'A mistake you made in your business and what you do now. The easiest post to write because you already lived it: [MISTAKE] → [FIX] → [QUESTION].'
      },
      {
        num: '02',
        headline: 'Proof of Process (Show the work, not the money)',
        body: 'Post what you actually did this week: orders packed, broilers weighed, clients booked, one hard lesson learned. Never fake income screenshots.'
      },
      {
        num: '03',
        headline: 'The Honest Opinion (Say what you actually think)',
        body: 'Unpopular opinion on your industry that normal people agree with deep down: [OPINION] → [HERE IS WHY] → [Agree or disagree?].'
      },
      {
        num: '04',
        headline: 'The Question (Ask something people can answer in one line)',
        body: '"What is the hardest part of [problem] for you right now?" or "[A] or [B]? Tell me why." Keep it dead simple to answer.'
      },
      {
        num: '05',
        headline: 'The Weekly Ask (Once a week, say what you sell)',
        body: 'One post a week where you state plainly who you help, what your offer is, and where the link is. No tricks, no "comment INFO".'
      }
    ],
    interactiveToolType: 'post_crafter',
    doThisNow: {
      title: 'Tomorrow: your first pitfall story.',
      steps: [
        'Pick one early mistake you made when starting your biashara.',
        'Fill in the template: I spent [time/money] doing [mistake]. Now I [fix]. What did you get wrong when you started?',
        'Post it tomorrow morning, then immediately do your 15-minute reply block.'
      ]
    },
    founderQuote: {
      text: 'I used to pay strangers $500 on Fiverr for fake promo shoutouts. Zero leads, wasted cash. Your own honest story and simple conversation posts cost zero shillings and build customers for life.',
      author: 'BiasharaBase'
    }
  },
  {
    id: 'ch04',
    num: '04',
    readTime: 'ABOUT 3 MIN',
    title: 'The 15-minute',
    highlightWords: ['reply block.'],
    subtitle: "This is the single habit that does the most work for your business: fifteen minutes a day, and most of it isn't even on your own posts.",
    endOfChapterOutcome: 'Your first 15-minute reply block, completed today.',
    corePoints: [
      {
        num: '01',
        headline: 'Set a 15-minute timer',
        body: 'Keep it intentionally short so you never procrastinate or get sucked into mindless doom-scrolling.'
      },
      {
        num: '02',
        headline: 'Find 5 to 10 bigger accounts in your lane',
        body: 'Accounts that already have the audience and buyers you want to serve in your industry.'
      },
      {
        num: '03',
        headline: 'Leave one real reply under a recent post from each',
        body: 'Add something, not applause! Two to four lines: a personal tip, a mini-story, or a thoughtful question. Never post a spam link in someone else\'s comments.'
      },
      {
        num: '04',
        headline: 'Answer every comment on your own posts',
        body: 'Every comment from the last 24 hours gets a meaningful, friendly reply. When readers see you answer, they comment more.'
      }
    ],
    interactiveToolType: 'reply_block',
    doThisNow: {
      title: 'Do your first block today.',
      steps: [
        'Set a 15-minute timer right now on your phone.',
        'Leave meaningful 2-line replies under 5 bigger accounts in your niche.',
        'Answer every single comment on your own recent posts.',
        'Repeat every single day at the same time.'
      ]
    },
    founderQuote: {
      text: 'My very first sales came right after that first week of doing 15-minute reply blocks. Showing up in the comments of bigger accounts is the fastest way to get noticed by high-intent buyers without paying for ads.',
      author: 'BiasharaBase'
    }
  },
  {
    id: 'ch05',
    num: '05',
    readTime: 'ABOUT 4 MIN',
    title: 'The weekly',
    highlightWords: ['ask.'],
    subtitle: 'Once a week, tell people what you sell and where to find it. Plainly. Then go right back to helping and talking.',
    endOfChapterOutcome: 'Your first weekly ask post, drafted for Day 7.',
    corePoints: [
      {
        num: '01',
        headline: 'Bio or first reply. Never in the post body.',
        body: 'Keep the main post body clean so the algorithm distributes it. Put your store link, WhatsApp number, or order link in your bio or your own first reply comment.'
      },
      {
        num: '02',
        headline: 'Say it once, plainly',
        body: 'Formula: "If you are [WHO] and struggling with [PROBLEM]... I made [OFFER]: [WHAT IS INSIDE]. It is not for you if [HONEST CAVEAT]. Link in my bio."'
      },
      {
        num: '03',
        headline: 'Skip the bait',
        body: 'Engagement bait like "Comment GUIDE and I\'ll DM you" backfires: Meta filters DM messages from non-followers into hidden request folders where links are automatically disabled!'
      },
      {
        num: '04',
        headline: 'Label your affiliate and commercial links',
        body: 'If a link pays you a commission or is a sponsored product, say so plainly. Radical honesty builds permanent buyer trust.'
      }
    ],
    interactiveToolType: 'weekly_ask_builder',
    doThisNow: {
      title: 'Draft your ask for Day 7.',
      steps: [
        'Fill in the weekly ask template: Who it is for, what is inside, and who it is NOT for.',
        'Decide where your link lives (Bio link or First Reply).',
        'Save it into your scheduler or draft folder for Day 7 of your plan.'
      ]
    },
    founderQuote: {
      text: 'One ask a week. The other six days are for giving value, sharing mistakes, and conversing. That rhythm is what makes the ask feel natural and welcome instead of spammy.',
      author: 'BiasharaBase'
    }
  },
  {
    id: 'ch06',
    num: '06',
    readTime: 'ABOUT 4 MIN',
    title: 'Posting with no',
    highlightWords: ['results and no face.'],
    subtitle: "You don't need millions in revenue or a face on camera to be worth following. You just need specifics and honesty.",
    endOfChapterOutcome: "A proof-of-process post with this week's effort numbers.",
    corePoints: [
      {
        num: '01',
        headline: 'Nothing to show yet? Show that.',
        body: 'Nobody expects a beginner to have flashy results. They do expect honesty. Share your effort numbers: [X] posts published, [Y] replies written, [Z] conversations started.'
      },
      {
        num: '02',
        headline: 'Faceless, but personal',
        body: 'You don\'t need selfies. Share photos of your workspace, your notebook sketches, your product packaging, your delivery boxes, or your computer screen.'
      },
      {
        num: '03',
        headline: 'Write like you talk',
        body: 'Short punchy lines. Real words you\'d say aloud to a friend. Throw out the corporate jargon.'
      },
      {
        num: '04',
        headline: 'When people you know see it',
        body: 'Friends or relatives might ask what you\'re doing. Your answer: "Yeah, I\'m learning to sell online. I post what I\'m doing so I stick with it." You don\'t owe anyone a speech.'
      }
    ],
    interactiveToolType: 'post_crafter',
    doThisNow: {
      title: 'Post your effort numbers.',
      steps: [
        'Count this week\'s output: posts published, replies written, real buyer chats started.',
        'Add one lesson you learned this week.',
        'End with an easy question, and post it with a simple photo of your desk or notes app.'
      ]
    },
    founderQuote: {
      text: 'Life outside the screen gets tough. Motivation drops, family doubts you, and sales take time. Showing up consistently and sharing your honest journey is the only real growth trick that works.',
      author: 'BiasharaBase'
    }
  },
  {
    id: 'ch07',
    num: '07',
    readTime: 'ABOUT 3 MIN',
    title: 'The 30-day plan,',
    highlightWords: ['two tracks.'],
    subtitle: 'A clear, fill-in-the-blank prompt for every single day of the month. Pick the track that fits your life, and switch when needed.',
    endOfChapterOutcome: 'Day 1 starts tomorrow morning.',
    corePoints: [
      {
        num: '01',
        headline: 'Daily Track (About 30 minutes a day)',
        body: 'One post and one 15-minute reply block, every single day. Best if you have 30 minutes in the morning or evening.'
      },
      {
        num: '02',
        headline: 'Light Track (About 2 hours a week)',
        body: 'Three posts (Days 1, 4, and 7) and two reply blocks (Days 2 and 5) per week. Perfect for busy parents or full-time workers.'
      },
      {
        num: '03',
        headline: 'Miss a day? Skip it.',
        body: 'Never try to double-up or post twice the next day. Just move directly to today\'s prompt and keep moving.'
      },
      {
        num: '04',
        headline: 'The Weekly Ask is always on Day 7, 14, 21, and 28',
        body: 'Consistency creates predictability. Your audience knows you sell, and they appreciate that you don\'t spam them daily.'
      }
    ],
    interactiveToolType: 'post_crafter',
    doThisNow: {
      title: 'Pick your track right now.',
      steps: [
        'Decide whether you are doing the Daily Track (30 min/day) or Light Track (2 hrs/week).',
        'Open Day 1 on the 30-Day Plan below.',
        'Fill in the blanks and schedule or publish your first Pitfall post tomorrow morning.'
      ]
    },
    founderQuote: {
      text: 'The 30-day plan works because it eliminates the daily paralysis of staring at a blank screen wondering what to say. Every day has a proven formula waiting for you.',
      author: 'BiasharaBase'
    }
  },
  {
    id: 'ch08',
    num: '08',
    readTime: 'ABOUT 3 MIN',
    title: 'Four numbers to',
    highlightWords: ['track.'],
    subtitle: 'Follower counts and view numbers go up and down randomly. These four controllable numbers show whether you are doing the work that leads to sales.',
    endOfChapterOutcome: 'A weekly reminder set on your phone, and Week 1 logged.',
    corePoints: [
      {
        num: '01',
        headline: '01 Posts published',
        body: 'Everything you published this week across all formats.'
      },
      {
        num: '02',
        headline: '02 Replies left',
        body: 'Meaningful comments you left under other accounts and under your own posts.'
      },
      {
        num: '03',
        headline: '03 Conversations started',
        body: 'A real, genuine back-and-forth exchange with a potential customer in comments or DMs.'
      },
      {
        num: '04',
        headline: '04 Asks made',
        body: 'Your weekly commercial asks where you invited people to buy your product or service.'
      }
    ],
    interactiveToolType: 'tracker',
    doThisNow: {
      title: 'Log Week 1.',
      steps: [
        'Set a recurring phone alarm every Sunday at 6:00 PM: "Log BiasharaBase Numbers".',
        'Record your 4 numbers in the tracker below (takes 3 minutes).',
        'Write down one single change you will test next week.'
      ]
    },
    founderQuote: {
      text: 'Views are nice for your ego, but views don\'t pay your suppliers or put food on your table. Tracking these four controllable actions is what reliably produces sales week after week.',
      author: 'BiasharaBase'
    }
  }
];

export const BIASHARA_30_DAY_PLAN: DayPrompt[] = [
  // WEEK 1: START TALKING
  {
    day: 1,
    week: 1,
    type: 'pitfall',
    typeName: 'PITFALL STORY',
    tagCode: 'P',
    lightTrackAction: 'POST',
    template: 'First mistake I made with [my business/lane]: I spent [time/money] doing [mistake]. Now I [what you do instead]. What did you get wrong when you started?',
    example: 'First mistake I made with commercial broilers: I tried mixing cheap pumba on Day 3 to save cash. It stunted their growth. Now I stick to starter crumble for the first 14 days without compromise. What did you get wrong when you started?',
    noCameraImageIdea: 'A screenshot of an old failed post, or a photo of your notebook showing your calculation.'
  },
  {
    day: 2,
    week: 1,
    type: 'question',
    typeName: 'QUESTION',
    tagCode: 'Q',
    lightTrackAction: 'REPLIES',
    template: "What's the hardest part of [the problem your audience faces] for you right now?",
    example: "What's the hardest part of building a side hustle while working a full-time 9-to-5 job right now?",
    noCameraImageIdea: 'A simple black and white card with the question written in big bold letters.'
  },
  {
    day: 3,
    week: 1,
    type: 'process',
    typeName: 'PROOF OF PROCESS',
    tagCode: 'W',
    lightTrackAction: 'OFF',
    template: 'This week in my business: [X] orders packed, [Y] replies sent. One big lesson: [one thing that surprised you]. What are you working on this week?',
    example: 'This week in my business: delivered 45 broilers, answered 18 customer WhatsApps. One big lesson: customers pay faster when you send a prompt WhatsApp receipt. What are you working on?',
    noCameraImageIdea: "A screenshot of your notes app with this week's checklist."
  },
  {
    day: 4,
    week: 1,
    type: 'opinion',
    typeName: 'HONEST OPINION',
    tagCode: 'O',
    lightTrackAction: 'POST',
    template: 'Unpopular opinion: [common advice] is completely overrated for beginners. Here is why: [your honest reason]. Agree or disagree?',
    example: 'Unpopular opinion: fancy logos and expensive websites are overrated for beginners. Talking directly to 5 real customers on WhatsApp will get you more sales than a $500 website. Agree or disagree?',
    noCameraImageIdea: 'A photo of a sticky note on your desk with the opinion handwritten.'
  },
  {
    day: 5,
    week: 1,
    type: 'pitfall',
    typeName: 'PITFALL STORY',
    tagCode: 'P',
    lightTrackAction: 'REPLIES',
    template: 'A mistake that cost me [amount of time/money]: [what happened]. The rule I follow today: [your rule]. Ever done this?',
    example: 'A mistake that cost me 3 months: waiting until everything was "perfect" before telling anyone what I sell. The rule I follow today: ship it messy and improve in public. Ever done this?',
    noCameraImageIdea: 'A photo of your desk or coffee cup with a simple caption.'
  },
  {
    day: 6,
    week: 1,
    type: 'question',
    typeName: 'QUESTION',
    tagCode: 'Q',
    lightTrackAction: 'OFF',
    template: 'Quick one: [Option A] or [Option B]? Tell me why in one sentence.',
    example: 'Quick one: Would you rather have 10 loyal repeat customers who buy every week, or 10,000 viral views that buy nothing? Tell me why.',
    noCameraImageIdea: 'A plain 2-tone split card with Option A vs Option B.'
  },
  {
    day: 7,
    week: 1,
    type: 'ask',
    typeName: 'WEEKLY ASK',
    tagCode: 'A',
    lightTrackAction: 'POST',
    template: "If you're [target audience] trying to [goal]: I made [your product/service]: [what is inside]. It is not for you if [honest boundary]. Link is in my bio / first comment.",
    example: "If you're a busy professional in Dar es Salaam looking for fresh, halal dressed broilers delivered to your gate every Saturday: Blessed Poultry has fresh harvest boxes ready. Link and order form is in my bio.",
    noCameraImageIdea: 'A photo of your packaged product or a clean screenshot of the first page of your guide/offer.'
  },

  // WEEK 2: GET SPECIFIC
  {
    day: 8,
    week: 2,
    type: 'pitfall',
    typeName: 'PITFALL STORY',
    tagCode: 'P',
    lightTrackAction: 'POST',
    template: 'I believed [common misconception] for way too long. It kept me stuck at [old situation]. Here is what actually changed things: [truth].',
    example: 'I believed that having the cheapest price would win me the most customers. It only won me the biggest headaches. Charging a fair price for premium quality changed everything.',
    noCameraImageIdea: 'A screenshot of a customer review praising your service.'
  },
  {
    day: 9,
    week: 2,
    type: 'question',
    typeName: 'QUESTION',
    tagCode: 'Q',
    lightTrackAction: 'REPLIES',
    template: 'What made you start [your industry/goal] in the first place? Was it freedom, extra income, or something else?',
    example: 'What made you start your side business in the first place? Was it extra income, building something of your own, or leaving a stressful job?',
    noCameraImageIdea: 'A high-contrast quote card with the question.'
  },
  {
    day: 10,
    week: 2,
    type: 'process',
    typeName: 'PROOF OF PROCESS',
    tagCode: 'W',
    lightTrackAction: 'OFF',
    template: 'Week 2 numbers: [X] replies left, [Y] customer chats started. Surprise of the week: [insight]. What did you learn this week?',
    example: 'Week 2 numbers: 45 comments left, 8 customer inquiries. Surprise of the week: people buy when you answer questions directly in DMs within 10 minutes. What did you learn?',
    noCameraImageIdea: 'A photo of your laptop screen or physical sales register book.'
  },
  {
    day: 11,
    week: 2,
    type: 'opinion',
    typeName: 'HONEST OPINION',
    tagCode: 'O',
    lightTrackAction: 'POST',
    template: "Hot take: you don't need [expensive/complicated tool] to start [goal]. You just need [simple habit].",
    example: "Hot take: you don't need an expensive marketing agency to get customers. You just need 15 minutes a day of helpful conversations and a reliable product.",
    noCameraImageIdea: 'A photo of your notepad with the hot take underlined.'
  },
  {
    day: 12,
    week: 2,
    type: 'pitfall',
    typeName: 'PITFALL STORY',
    tagCode: 'P',
    lightTrackAction: 'REPLIES',
    template: "The advice I wish I'd ignored when I started: '[bad advice]'. What's the worst advice you received in your field?",
    example: "The advice I wish I'd ignored: 'Give customers unlimited credit so they like you.' It almost killed my cash flow. What's the worst business advice you've been given?",
    noCameraImageIdea: 'A text card with a red X over the bad advice.'
  },
  {
    day: 13,
    week: 2,
    type: 'question',
    typeName: 'QUESTION',
    tagCode: 'Q',
    lightTrackAction: 'OFF',
    template: "What's stopping you from taking the first step on [goal] today? Be honest.",
    example: "What's stopping you from launching your digital product or starting your first 200 broiler batch today? Be honest.",
    noCameraImageIdea: 'A clean card with the question in bold text.'
  },
  {
    day: 14,
    week: 2,
    type: 'ask',
    typeName: 'WEEKLY ASK',
    tagCode: 'A',
    lightTrackAction: 'POST',
    template: 'Who this is for: [Person A] and [Person B]. Who it is NOT for: [Person C]. If you want [Outcome], link in my bio.',
    example: 'Who our farm boxes are for: busy families and meal-preppers who want fresh, organic broiler chicken without market hassle. Who it is not for: bulk resellers looking for lowest grade scrap. Order link in bio.',
    noCameraImageIdea: 'A photo of your product packaging with your brand label.'
  },

  // WEEK 3: GO DEEPER
  {
    day: 15,
    week: 3,
    type: 'pitfall',
    typeName: 'PITFALL STORY',
    tagCode: 'P',
    lightTrackAction: 'POST',
    template: 'I almost quit my biashara when [hard event]. Here is what kept me going: [reason]. Have you had a moment like this?',
    example: 'I almost quit when a power outage almost chilled our brooder chicks in week 1. Staying up all night taught me resilience and backup planning. Have you ever had a moment where you almost threw in the towel?',
    noCameraImageIdea: 'A personal photo of your workspace at night or early morning.'
  },
  {
    day: 16,
    week: 3,
    type: 'question',
    typeName: 'QUESTION',
    tagCode: 'Q',
    lightTrackAction: 'REPLIES',
    template: 'Which is harder for you right now: getting your first 10 customers, or delivering consistently? Tell me why.',
    example: 'Which is harder for you right now: getting the courage to announce your prices, or finding buyers who pay on time?',
    noCameraImageIdea: 'A simple comparison card.'
  },
  {
    day: 17,
    week: 3,
    type: 'process',
    typeName: 'PROOF OF PROCESS',
    tagCode: 'W',
    lightTrackAction: 'OFF',
    template: '3 weeks of posting consistently taught me: [Lesson 1], [Lesson 2], and [Lesson 3]. Anyone else noticing this?',
    example: '3 weeks of replying to comments taught me: 1. People buy from people they trust. 2. Short posts get more replies than essays. 3. Direct DMs close deals. Anyone else seeing this?',
    noCameraImageIdea: 'A screenshot of your weekly stats or engagement chart.'
  },
  {
    day: 18,
    week: 3,
    type: 'opinion',
    typeName: 'HONEST OPINION',
    tagCode: 'O',
    lightTrackAction: 'POST',
    template: 'Everyone in [industry] says you have to [trend]. I disagree. Here is what works better: [alternative]. Thoughts?',
    example: 'Everyone says you need to dance in TikTok reels to sell products. I disagree. Clear text posts with good photos and honest customer service close more sales with zero cringe. Thoughts?',
    noCameraImageIdea: 'A handwritten quote card.'
  },
  {
    day: 19,
    week: 3,
    type: 'pitfall',
    typeName: 'PITFALL STORY',
    tagCode: 'P',
    lightTrackAction: 'REPLIES',
    template: 'A tool / service I paid for and never used: [Tool]. What I use now instead: [Free/Simple tool]. What is one subscription you regret buying?',
    example: 'A tool I paid for and never used: a $49/month complex CRM. What I use now instead: WhatsApp Business labels and Google Sheets. Simple always wins.',
    noCameraImageIdea: 'A screenshot of a clean minimalist tool or spreadsheet.'
  },
  {
    day: 20,
    week: 3,
    type: 'question',
    typeName: 'QUESTION',
    tagCode: 'Q',
    lightTrackAction: 'OFF',
    template: 'If you could ask me one honest question about [my lane/business], what would it be? Answering all in the replies.',
    example: 'If you could ask me one honest question about starting a commercial broiler farm in Tanzania, what would it be? Answering all in comments today.',
    noCameraImageIdea: 'An "Ask Me Anything" simple text card.'
  },
  {
    day: 21,
    week: 3,
    type: 'ask',
    typeName: 'WEEKLY ASK',
    tagCode: 'A',
    lightTrackAction: 'POST',
    template: 'One specific problem my offer fixes: [Problem]. How it fixes it: [Solution]. Link is in my bio.',
    example: 'One specific problem Blessed Poultry fixes: tough, frozen supermarket chickens that have been in cold storage for months. We harvest fresh every 2 weeks. Reserve your fresh box in my bio.',
    noCameraImageIdea: 'A photo of fresh orders ready for delivery.'
  },

  // WEEK 4: KEEP GOING
  {
    day: 22,
    week: 4,
    type: 'pitfall',
    typeName: 'PITFALL STORY',
    tagCode: 'P',
    lightTrackAction: 'POST',
    template: 'My most expensive mistake in business: [story]. How I avoid it today: [rule]. What was your most expensive lesson?',
    example: 'My most expensive mistake: giving chickens on unmonitored credit to restaurants without a 48-hour cutoff. Cash flow is oxygen. Always protect your working capital.',
    noCameraImageIdea: 'A photo of your ledger or receipt book.'
  },
  {
    day: 23,
    week: 4,
    type: 'question',
    typeName: 'QUESTION',
    tagCode: 'Q',
    lightTrackAction: 'REPLIES',
    template: "Finish this sentence in the replies: I'd post and sell more if...",
    example: "Finish this sentence in the replies: I'd launch my side business tomorrow if...",
    noCameraImageIdea: 'A big font fill-in-the-blank prompt.'
  },
  {
    day: 24,
    week: 4,
    type: 'process',
    typeName: 'PROOF OF PROCESS',
    tagCode: 'W',
    lightTrackAction: 'OFF',
    template: "Day 24 of building in public: What is working: [A]. What isn't working: [B]. How I am pivoting: [C].",
    example: "Day 24 of building our customer base: What is working: WhatsApp voice notes and direct customer check-ins. What isn't: generic announcements. Keep iterating.",
    noCameraImageIdea: 'A photo of your work desk or whiteboard notes.'
  },
  {
    day: 25,
    week: 4,
    type: 'opinion',
    typeName: 'HONEST OPINION',
    tagCode: 'O',
    lightTrackAction: 'POST',
    template: 'Most overrated advice in [industry]: [Advice]. Most underrated advice: [Advice]. Do you agree?',
    example: 'Most overrated advice in small business: "Scale as fast as possible." Most underrated advice: "Make sure every single transaction is profitable first." Do you agree?',
    noCameraImageIdea: 'A split comparison card.'
  },
  {
    day: 26,
    week: 4,
    type: 'pitfall',
    typeName: 'PITFALL STORY',
    tagCode: 'P',
    lightTrackAction: 'REPLIES',
    template: 'What I would do completely differently if I restarted from zero today: [Step 1], [Step 2], [Step 3]. What would you change?',
    example: 'What I would do differently if restarting: 1. Build a waiting list before buying inventory. 2. Collect cash on delivery. 3. Show up in customer DMs daily.',
    noCameraImageIdea: 'A 3-step minimalist text card.'
  },
  {
    day: 27,
    week: 4,
    type: 'question',
    typeName: 'QUESTION',
    tagCode: 'Q',
    lightTrackAction: 'OFF',
    template: "What's one small win you had in your business this month? Brag a little in the replies below.",
    example: "What's one small win you had in your side hustle or farm this month? Brag a little in the comments, let's celebrate each other.",
    noCameraImageIdea: 'A cheerful celebration question card.'
  },
  {
    day: 28,
    week: 4,
    type: 'ask',
    typeName: 'WEEKLY ASK',
    tagCode: 'A',
    lightTrackAction: 'POST',
    template: 'This month in one sentence: [Summary]. Here is our offer for next month: [Offer]. Link in bio.',
    example: 'This month in one sentence: sold out 200 broilers and built 15 repeat family customers. Pre-orders for our next harvest batch are now live. Link in bio.',
    noCameraImageIdea: 'A photo of happy customer deliveries or package ready to go.'
  },

  // DAYS 29 & 30: FINISH STRONG
  {
    day: 29,
    week: 4,
    type: 'followup',
    typeName: 'FOLLOW-UP POST',
    tagCode: 'F',
    lightTrackAction: 'POST',
    template: 'Go back to your best-performing post of the month. Write a follow-up: what people said, what surprised you, and what you think now.',
    example: 'Last week I posted about why we don\'t give unlimited credit to restaurants. Over 80 business owners replied sharing their horror stories. Here is the contract template we now use.',
    noCameraImageIdea: 'A screenshot of the replies under your best post.'
  },
  {
    day: 30,
    week: 4,
    type: 'review',
    typeName: 'REVIEW & NUMBERS',
    tagCode: 'R',
    lightTrackAction: 'SAME',
    template: 'Log your 4 numbers in the tracker. Read your bio lane line again. Still true? Keep it. If not, refine it. Then start again at Week 1 with everything you learned.',
    example: 'Day 30 check: Logged 28 posts, 160 replies, 24 buyer conversations, 4 asks made. Sales up 40%. The prompts work even better the second time around because your answers will be sharper.',
    noCameraImageIdea: 'A photo of your completed 30-day tracker sheet.'
  }
];

export const DAY_PROMPTS = BIASHARA_30_DAY_PLAN;

export interface PromptExtraItem {
  id: string;
  category: string;
  prompt: string;
  whyItWorks: string;
  example: string;
}

export const PROMPT_BANK_EXTRAS: PromptExtraItem[] = [
  {
    id: 'extra_1',
    category: 'PITFALL',
    prompt: "The first thing I'd tell any beginner in [my industry]: [common fatal pitfall to avoid].",
    whyItWorks: 'Positions you immediately as an experienced peer, not a sales pitch.',
    example: "The first thing I'd tell any beginner raising broilers: spend your money on good brooding heat and clean water before buying fancy expensive supplements."
  },
  {
    id: 'extra_2',
    category: 'PITFALL',
    prompt: 'I wasted [amount of time/money] on [mistake]. Here is the simple alternative that works 10x better: [proven method].',
    whyItWorks: 'Vulnerability builds immense trust and sparks shared stories in replies.',
    example: 'I wasted TSh 300,000 on Instagram boost ads. Asking 10 existing happy customers for WhatsApp referrals brought in 5x more orders for free.'
  },
  {
    id: 'extra_3',
    category: 'QUESTION',
    prompt: "What's one business tool, service or subscription you would never pay for again?",
    whyItWorks: 'Negative experiences provoke high engagement and debate in comments.',
    example: "What's one business tool or course you would never pay for again, and why?"
  },
  {
    id: 'extra_4',
    category: 'QUESTION',
    prompt: "What's your single favorite free app or tool for running your business right now?",
    whyItWorks: 'Crowdsources practical recommendations that people save and bookmark.',
    example: "What's your favorite free tool for running your business? (Mine is WhatsApp Business quick-reply labels)."
  },
  {
    id: 'extra_5',
    category: 'PROCESS',
    prompt: "A photo or screenshot of this week's order tracker, plus the one single lesson it taught me.",
    whyItWorks: 'Lived operational evidence is 100x more believable than motivational quotes.',
    example: 'A photo of our farm ledger showing Day 35 harvest numbers and feed conversion efficiency.'
  },
  {
    id: 'extra_6',
    category: 'PROCESS',
    prompt: 'What I am testing next week in my business: [experiment]. I will report back on Friday with the raw numbers.',
    whyItWorks: 'Creates an open narrative loop that invites followers to return for part 2.',
    example: 'What I am testing next week: offering 5% discount for instant M-Pesa on delivery instead of allowing 3-day credit.'
  },
  {
    id: 'extra_7',
    category: 'OPINION',
    prompt: '[Common belief] is much harder than influencers make it look online. Here is the unvarnished reality.',
    whyItWorks: 'Cuts through toxic positivity and earns deep respect from real practitioners.',
    example: 'Running a poultry farm looks easy in 30-second videos. Here is the unvarnished reality of brooding chicks at 3:00 AM during heavy rain.'
  },
  {
    id: 'extra_8',
    category: 'OPINION',
    prompt: 'I completely changed my mind about [topic]. Here is what made me switch.',
    whyItWorks: 'Intellectual honesty signals maturity and high domain competence.',
    example: 'I used to think direct household retail was too tedious. I changed my mind when I saw cash in hand within 10 minutes of delivery.'
  },
  {
    id: 'extra_9',
    category: 'ASK',
    prompt: 'The question I get asked most in DMs, answered. Plus where to get the full solution in my bio.',
    whyItWorks: 'Answers a real objection publicly, then naturally points to your product.',
    example: 'The question I get most: "Where do you get your day-old chicks?" Here is our supplier vetting guide. Link in bio.'
  }
];

export const INITIAL_METRIC_ROWS: WeeklyMetricRow[] = [
  { week: 1, posts: 7, replies: 48, convos: 6, asks: 1, oneThingToChange: 'Leave replies earlier in the morning when people are commuting.' },
  { week: 2, posts: 7, replies: 56, convos: 9, asks: 1, oneThingToChange: 'Make questions in post endings shorter and easier to answer.' },
  { week: 3, posts: 7, replies: 62, convos: 12, asks: 1, oneThingToChange: 'Follow up faster in DMs when people ask about prices.' },
  { week: 4, posts: 8, replies: 70, convos: 15, asks: 1, oneThingToChange: 'Offer a weekend bundle package for repeat household buyers.' }
];


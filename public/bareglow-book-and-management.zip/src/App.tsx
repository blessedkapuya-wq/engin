/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import Header from './components/Header';
import SalonShopBook from './components/SalonShopBook';
import StockAlertsManager from './components/StockAlertsManager';
import ClientSalonView from './components/ClientSalonView';
import StaffReportForm from './components/StaffReportForm';
import ReportDocumentPreview from './components/ReportDocumentPreview';
import OwnerPortal from './components/OwnerPortal';
import AppInstallModal from './components/AppInstallModal';
import ChickenManagementApp from './components/ChickenManagementApp';
import BiasharaBaseApp from './components/BiasharaBaseApp';
import {
  StaffReport,
  StaffMember,
  OwnerVaultState,
  InventoryItem,
  SalonExpense,
  DailySaleEntry,
  DailyTillHandover
} from './types/salon';
import {
  PoultryBatch,
  VaccinationRecord,
  FeedRecord,
  MortalityRecord,
  PoultryExpense,
  PoultrySale
} from './types/poultry';
import {
  SAMPLE_REPORT,
  INITIAL_STAFF_MEMBERS,
  INITIAL_OWNER_VAULT,
  INITIAL_INVENTORY,
  INITIAL_EXPENSES,
  INITIAL_DAILY_SALES,
  INITIAL_TILL_HANDOVERS
} from './data/initialData';
import {
  INITIAL_POULTRY_BATCHES,
  INITIAL_VACCINATIONS,
  INITIAL_FEEDS,
  INITIAL_MORTALITY,
  INITIAL_POULTRY_EXPENSES,
  INITIAL_POULTRY_SALES
} from './data/initialPoultryData';
import { SALON_INFO } from './data/bareglowCatalog';
import { BookOpen, AlertTriangle, FileText, Printer, Lock, Scissors, QrCode, Bird, BookMarked } from 'lucide-react';
import { syncService } from './services/syncService';
import { testConnection } from './firebase';

export default function App() {
  const [activeBusiness, setActiveBusiness] = useState<'poultry' | 'salon' | 'biashara'>('biashara');
  const [currentView, setCurrentView] = useState<'shopbook' | 'inventory' | 'salon' | 'form' | 'preview' | 'owner' | 'poultry' | 'biashara'>('biashara');
  const [cloudConnected, setCloudConnected] = useState<boolean>(true);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState<boolean>(false);

  // BLESSED POULTRY FARM DATA STATE & PERSISTENCE (TANZANIA - TZS)
  const [poultryBatches, setPoultryBatches] = useState<PoultryBatch[]>(() => {
    try {
      const isTz = localStorage.getItem('blessed_poultry_currency_tz');
      const saved = localStorage.getItem('blessed_poultry_batches');
      if (saved && isTz === 'TZS') {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].id && parsed[0].id.includes('tz')) {
          return parsed;
        }
      }
    } catch (e) {
      console.error(e);
    }
    try {
      localStorage.setItem('blessed_poultry_currency_tz', 'TZS');
    } catch (e) {}
    return INITIAL_POULTRY_BATCHES;
  });

  const [poultryVaccinations, setPoultryVaccinations] = useState<VaccinationRecord[]>(() => {
    try {
      const isTz = localStorage.getItem('blessed_poultry_currency_tz');
      const saved = localStorage.getItem('blessed_poultry_vaccinations');
      if (saved && isTz === 'TZS') {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].id && parsed[0].id.includes('tz')) {
          return parsed;
        }
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_VACCINATIONS;
  });

  const [poultryFeeds, setPoultryFeeds] = useState<FeedRecord[]>(() => {
    try {
      const isTz = localStorage.getItem('blessed_poultry_currency_tz');
      const saved = localStorage.getItem('blessed_poultry_feeds');
      if (saved && isTz === 'TZS') {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].id && parsed[0].id.includes('tz')) {
          return parsed;
        }
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_FEEDS;
  });

  const [poultryMortalities, setPoultryMortalities] = useState<MortalityRecord[]>(() => {
    try {
      const isTz = localStorage.getItem('blessed_poultry_currency_tz');
      const saved = localStorage.getItem('blessed_poultry_mortalities');
      if (saved && isTz === 'TZS') {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].id && parsed[0].id.includes('tz')) {
          return parsed;
        }
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_MORTALITY;
  });

  const [poultryExpenses, setPoultryExpenses] = useState<PoultryExpense[]>(() => {
    try {
      const isTz = localStorage.getItem('blessed_poultry_currency_tz');
      const saved = localStorage.getItem('blessed_poultry_expenses');
      if (saved && isTz === 'TZS') {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].id && parsed[0].id.includes('tz')) {
          return parsed;
        }
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_POULTRY_EXPENSES;
  });

  const [poultrySales, setPoultrySales] = useState<PoultrySale[]>(() => {
    try {
      const isTz = localStorage.getItem('blessed_poultry_currency_tz');
      const saved = localStorage.getItem('blessed_poultry_sales');
      if (saved && isTz === 'TZS') {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].id && parsed[0].id.includes('tz')) {
          return parsed;
        }
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_POULTRY_SALES;
  });

  // Handler to Reset Poultry Data to Clean Tanzania (TZS) Standards
  const handleResetToTanzaniaData = () => {
    setPoultryBatches(INITIAL_POULTRY_BATCHES);
    setPoultryVaccinations(INITIAL_VACCINATIONS);
    setPoultryFeeds(INITIAL_FEEDS);
    setPoultryMortalities(INITIAL_MORTALITY);
    setPoultryExpenses(INITIAL_POULTRY_EXPENSES);
    setPoultrySales(INITIAL_POULTRY_SALES);
    try {
      localStorage.setItem('blessed_poultry_currency_tz', 'TZS');
      localStorage.setItem('blessed_poultry_batches', JSON.stringify(INITIAL_POULTRY_BATCHES));
      localStorage.setItem('blessed_poultry_vaccinations', JSON.stringify(INITIAL_VACCINATIONS));
      localStorage.setItem('blessed_poultry_feeds', JSON.stringify(INITIAL_FEEDS));
      localStorage.setItem('blessed_poultry_mortalities', JSON.stringify(INITIAL_MORTALITY));
      localStorage.setItem('blessed_poultry_expenses', JSON.stringify(INITIAL_POULTRY_EXPENSES));
      localStorage.setItem('blessed_poultry_sales', JSON.stringify(INITIAL_POULTRY_SALES));
    } catch (e) {
      console.error(e);
    }
  };

  // Sync poultry states to localStorage with TZS flag
  useEffect(() => {
    try {
      localStorage.setItem('blessed_poultry_currency_tz', 'TZS');
      localStorage.setItem('blessed_poultry_batches', JSON.stringify(poultryBatches));
    } catch (e) {
      console.error(e);
    }
  }, [poultryBatches]);

  useEffect(() => {
    try {
      localStorage.setItem('blessed_poultry_vaccinations', JSON.stringify(poultryVaccinations));
    } catch (e) {
      console.error(e);
    }
  }, [poultryVaccinations]);

  useEffect(() => {
    try {
      localStorage.setItem('blessed_poultry_feeds', JSON.stringify(poultryFeeds));
    } catch (e) {
      console.error(e);
    }
  }, [poultryFeeds]);

  useEffect(() => {
    try {
      localStorage.setItem('blessed_poultry_mortalities', JSON.stringify(poultryMortalities));
    } catch (e) {
      console.error(e);
    }
  }, [poultryMortalities]);

  useEffect(() => {
    try {
      localStorage.setItem('blessed_poultry_expenses', JSON.stringify(poultryExpenses));
    } catch (e) {
      console.error(e);
    }
  }, [poultryExpenses]);

  useEffect(() => {
    try {
      localStorage.setItem('blessed_poultry_sales', JSON.stringify(poultrySales));
    } catch (e) {
      console.error(e);
    }
  }, [poultrySales]);

  // Inventory state with Stock Alerts
  const [inventory, setInventory] = useState<InventoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('bareglow_inventory');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_INVENTORY;
  });

  // Sales entries for Shop Book
  const [sales, setSales] = useState<DailySaleEntry[]>(() => {
    try {
      const saved = localStorage.getItem('bareglow_sales');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_DAILY_SALES;
  });

  // Expenses entries for Shop Book ("EXPENSIVE")
  const [expenses, setExpenses] = useState<SalonExpense[]>(() => {
    try {
      const saved = localStorage.getItem('bareglow_expenses');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_EXPENSES;
  });

  // Reports collection stored in localStorage
  const [reports, setReports] = useState<StaffReport[]>(() => {
    try {
      const saved = localStorage.getItem('bareglow_reports');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [SAMPLE_REPORT];
  });

  // Owner Vault state stored in localStorage
  const [vaultState, setVaultState] = useState<OwnerVaultState>(() => {
    try {
      const saved = localStorage.getItem('bareglow_owner_vault');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_OWNER_VAULT;
  });

  // Current active report being edited or previewed
  const [activeReport, setActiveReport] = useState<StaffReport>(reports[0] || SAMPLE_REPORT);
  const [staffList, setStaffList] = useState<StaffMember[]>(() => {
    try {
      const saved = localStorage.getItem('bareglow_staff_roster');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_STAFF_MEMBERS;
  });

  // Daily Till Handovers & Reconciliations
  const [handovers, setHandovers] = useState<DailyTillHandover[]>(() => {
    try {
      const saved = localStorage.getItem('bareglow_till_handovers');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_TILL_HANDOVERS;
  });

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('bareglow_inventory', JSON.stringify(inventory));
    } catch (e) {
      console.error(e);
    }
  }, [inventory]);

  useEffect(() => {
    try {
      localStorage.setItem('bareglow_sales', JSON.stringify(sales));
    } catch (e) {
      console.error(e);
    }
  }, [sales]);

  useEffect(() => {
    try {
      localStorage.setItem('bareglow_expenses', JSON.stringify(expenses));
    } catch (e) {
      console.error(e);
    }
  }, [expenses]);

  useEffect(() => {
    try {
      localStorage.setItem('bareglow_reports', JSON.stringify(reports));
    } catch (e) {
      console.error(e);
    }
  }, [reports]);

  useEffect(() => {
    try {
      localStorage.setItem('bareglow_owner_vault', JSON.stringify(vaultState));
    } catch (e) {
      console.error(e);
    }
  }, [vaultState]);

  useEffect(() => {
    try {
      localStorage.setItem('bareglow_staff_roster', JSON.stringify(staffList));
    } catch (e) {
      console.error(e);
    }
  }, [staffList]);

  useEffect(() => {
    try {
      localStorage.setItem('bareglow_till_handovers', JSON.stringify(handovers));
    } catch (e) {
      console.error(e);
    }
  }, [handovers]);

  // Real-time Cloud Sync with Google Cloud Firestore
  useEffect(() => {
    testConnection().then((connected) => {
      setCloudConnected(connected);
    });

    // Subscribe to remote sales changes
    const unsubSales = syncService.subscribeToSales((remoteSales) => {
      setSales((currentLocal) => {
        const merged = [...currentLocal];
        remoteSales.forEach((remote) => {
          const idx = merged.findIndex((m) => m.id === remote.id);
          if (idx >= 0) {
            merged[idx] = remote;
          } else {
            merged.unshift(remote);
          }
        });
        return merged;
      });
    });

    // Subscribe to remote expenses changes
    const unsubExpenses = syncService.subscribeToExpenses((remoteExpenses) => {
      setExpenses((currentLocal) => {
        const merged = [...currentLocal];
        remoteExpenses.forEach((remote) => {
          const idx = merged.findIndex((m) => m.id === remote.id);
          if (idx >= 0) {
            merged[idx] = remote;
          } else {
            merged.unshift(remote);
          }
        });
        return merged;
      });
    });

    // Subscribe to remote till handovers
    const unsubHandovers = syncService.subscribeToHandovers((remoteHandovers) => {
      setHandovers((currentLocal) => {
        const merged = [...currentLocal];
        remoteHandovers.forEach((remote) => {
          const idx = merged.findIndex((m) => m.id === remote.id);
          if (idx >= 0) {
            merged[idx] = remote;
          } else {
            merged.unshift(remote);
          }
        });
        return merged;
      });
    });

    // Subscribe to remote poultry batches
    const unsubPoultryBatches = syncService.subscribeToPoultryBatches((remoteBatches) => {
      setPoultryBatches((currentLocal) => {
        const merged = [...currentLocal];
        remoteBatches.forEach((remote) => {
          const idx = merged.findIndex((m) => m.id === remote.id);
          if (idx >= 0) {
            merged[idx] = remote;
          } else {
            merged.unshift(remote);
          }
        });
        return merged;
      });
    });

    // Subscribe to remote poultry sales
    const unsubPoultrySales = syncService.subscribeToPoultrySales((remoteSales) => {
      setPoultrySales((currentLocal) => {
        const merged = [...currentLocal];
        remoteSales.forEach((remote) => {
          const idx = merged.findIndex((m) => m.id === remote.id);
          if (idx >= 0) {
            merged[idx] = remote;
          } else {
            merged.unshift(remote);
          }
        });
        return merged;
      });
    });

    // Subscribe to remote poultry expenses
    const unsubPoultryExpenses = syncService.subscribeToPoultryExpenses((remoteExp) => {
      setPoultryExpenses((currentLocal) => {
        const merged = [...currentLocal];
        remoteExp.forEach((remote) => {
          const idx = merged.findIndex((m) => m.id === remote.id);
          if (idx >= 0) {
            merged[idx] = remote;
          } else {
            merged.unshift(remote);
          }
        });
        return merged;
      });
    });

    // Subscribe to remote poultry feeds
    const unsubPoultryFeeds = syncService.subscribeToPoultryFeeds((remoteFeeds) => {
      setPoultryFeeds((currentLocal) => {
        const merged = [...currentLocal];
        remoteFeeds.forEach((remote) => {
          const idx = merged.findIndex((m) => m.id === remote.id);
          if (idx >= 0) {
            merged[idx] = remote;
          } else {
            merged.unshift(remote);
          }
        });
        return merged;
      });
    });

    // Subscribe to remote poultry vaccines
    const unsubPoultryVaccines = syncService.subscribeToPoultryVaccines((remoteVax) => {
      setPoultryVaccinations((currentLocal) => {
        const merged = [...currentLocal];
        remoteVax.forEach((remote) => {
          const idx = merged.findIndex((m) => m.id === remote.id);
          if (idx >= 0) {
            merged[idx] = remote;
          } else {
            merged.unshift(remote);
          }
        });
        return merged;
      });
    });

    // Subscribe to remote poultry mortalities
    const unsubPoultryMortalities = syncService.subscribeToPoultryMortalities((remoteMort) => {
      setPoultryMortalities((currentLocal) => {
        const merged = [...currentLocal];
        remoteMort.forEach((remote) => {
          const idx = merged.findIndex((m) => m.id === remote.id);
          if (idx >= 0) {
            merged[idx] = remote;
          } else {
            merged.unshift(remote);
          }
        });
        return merged;
      });
    });

    return () => {
      unsubSales();
      unsubExpenses();
      unsubHandovers();
      unsubPoultryBatches();
      unsubPoultrySales();
      unsubPoultryExpenses();
      unsubPoultryFeeds();
      unsubPoultryVaccines();
      unsubPoultryMortalities();
    };
  }, []);

  // Poultry Handlers with Cloud Firestore backup
  const handleAddPoultryBatch = (batch: PoultryBatch) => {
    setPoultryBatches((prev) => [batch, ...prev]);
    syncService.savePoultryBatch(batch).catch((err) => console.warn('Cloud sync batch error:', err));
  };

  const handleUpdatePoultryBatch = (batches: PoultryBatch[]) => {
    setPoultryBatches(batches);
    batches.forEach((b) => {
      syncService.savePoultryBatch(b).catch((err) => console.warn('Cloud sync batch error:', err));
    });
  };

  const handleAddPoultrySale = (sale: PoultrySale) => {
    setPoultrySales((prev) => [sale, ...prev]);
    syncService.savePoultrySale(sale).catch((err) => console.warn('Cloud sync sale error:', err));
  };

  const handleUpdatePoultrySale = (sales: PoultrySale[]) => {
    setPoultrySales(sales);
    sales.forEach((s) => {
      syncService.savePoultrySale(s).catch((err) => console.warn('Cloud sync sale error:', err));
    });
  };

  const handleAddPoultryExpense = (expense: PoultryExpense) => {
    setPoultryExpenses((prev) => [expense, ...prev]);
    syncService.savePoultryExpense(expense).catch((err) => console.warn('Cloud sync expense error:', err));
  };

  const handleAddPoultryFeed = (feed: FeedRecord) => {
    setPoultryFeeds((prev) => [feed, ...prev]);
    syncService.savePoultryFeed(feed).catch((err) => console.warn('Cloud sync feed error:', err));
  };

  const handleAddPoultryVaccination = (vax: VaccinationRecord) => {
    setPoultryVaccinations((prev) => [vax, ...prev]);
    syncService.savePoultryVaccine(vax).catch((err) => console.warn('Cloud sync vaccine error:', err));
  };

  const handleUpdatePoultryVaccination = (vaxes: VaccinationRecord[]) => {
    setPoultryVaccinations(vaxes);
    vaxes.forEach((v) => {
      syncService.savePoultryVaccine(v).catch((err) => console.warn('Cloud sync vaccine error:', err));
    });
  };

  const handleAddPoultryMortality = (mort: MortalityRecord) => {
    setPoultryMortalities((prev) => [mort, ...prev]);
    syncService.savePoultryMortality(mort).catch((err) => console.warn('Cloud sync mortality error:', err));
  };

  const handleManualSyncPoultryToCloud = async () => {
    return await syncService.syncAllPoultryData({
      batches: poultryBatches,
      sales: poultrySales,
      expenses: poultryExpenses,
      feeds: poultryFeeds,
      vaccinations: poultryVaccinations,
      mortalities: poultryMortalities
    });
  };

  const handleRestorePoultryBackup = (data: any) => {
    if (data.batches && Array.isArray(data.batches)) setPoultryBatches(data.batches);
    if (data.sales && Array.isArray(data.sales)) setPoultrySales(data.sales);
    if (data.expenses && Array.isArray(data.expenses)) setPoultryExpenses(data.expenses);
    if (data.feeds && Array.isArray(data.feeds)) setPoultryFeeds(data.feeds);
    if (data.vaccinations && Array.isArray(data.vaccinations)) setPoultryVaccinations(data.vaccinations);
    if (data.mortalities && Array.isArray(data.mortalities)) setPoultryMortalities(data.mortalities);
    syncService.syncAllPoultryData({
      batches: data.batches || poultryBatches,
      sales: data.sales || poultrySales,
      expenses: data.expenses || poultryExpenses,
      feeds: data.feeds || poultryFeeds,
      vaccinations: data.vaccinations || poultryVaccinations,
      mortalities: data.mortalities || poultryMortalities
    }).catch((e) => console.warn('Cloud sync restore error:', e));
  };

  const handleSaveHandover = (newHandover: DailyTillHandover) => {
    setHandovers((prev) => [newHandover, ...prev.filter((h) => h.id !== newHandover.id)]);
    syncService.saveHandover(newHandover).catch((err) => console.warn('Cloud sync handover error:', err));
  };

  // Restore complete salon data from backup file
  const handleRestoreBackup = (data: any) => {
    if (data.sales && Array.isArray(data.sales)) setSales(data.sales);
    if (data.expenses && Array.isArray(data.expenses)) setExpenses(data.expenses);
    if (data.reports && Array.isArray(data.reports)) setReports(data.reports);
    if (data.vaultState) setVaultState(data.vaultState);
    if (data.staffList && Array.isArray(data.staffList)) setStaffList(data.staffList);
    if (data.handovers && Array.isArray(data.handovers)) setHandovers(data.handovers);
    if (data.inventory && Array.isArray(data.inventory)) setInventory(data.inventory);
  };

  // Handle adding sale in Shop Book: auto-deducts stock if a product was sold!
  const handleAddSale = (newSale: DailySaleEntry) => {
    setSales((prev) => [newSale, ...prev]);
    syncService.saveSale(newSale).catch((err) => console.warn('Cloud sync sale error:', err));

    // If it's a product, decrement stock
    if (newSale.type === 'Product Retail') {
      setInventory((prev) =>
        prev.map((item) => {
          if (item.name.toLowerCase() === newSale.itemName.toLowerCase() || newSale.itemName.includes(item.name)) {
            const updatedStock = Math.max(0, item.stockQuantity - newSale.quantity);
            return { ...item, stockQuantity: updatedStock };
          }
          return item;
        })
      );
    }

    // Update gross sales in owner vault
    setVaultState((prev) => {
      const updated = {
        ...prev,
        totalGrossRevenueKSh: prev.totalGrossRevenueKSh + newSale.amountKSh,
        withdrawableProfitKSh: prev.withdrawableProfitKSh + Math.round(newSale.amountKSh * 0.45)
      };
      syncService.saveVault(updated).catch((err) => console.warn('Cloud sync vault error:', err));
      return updated;
    });
  };

  // Handle adding expense in Shop Book
  const handleAddExpense = (newExpense: SalonExpense) => {
    setExpenses((prev) => [newExpense, ...prev]);
    syncService.saveExpense(newExpense).catch((err) => console.warn('Cloud sync expense error:', err));

    setVaultState((prev) => {
      const updated = {
        ...prev,
        operatingExpensesKSh: prev.operatingExpensesKSh + newExpense.amountKSh,
        withdrawableProfitKSh: Math.max(0, prev.withdrawableProfitKSh - newExpense.amountKSh)
      };
      syncService.saveVault(updated).catch((err) => console.warn('Cloud sync vault error:', err));
      return updated;
    });
  };

  // Handle updates to active report
  const handleUpdateReport = (updated: StaffReport) => {
    setActiveReport(updated);
    setReports((prev) => {
      const idx = prev.findIndex((r) => r.id === updated.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = updated;
        return copy;
      }
      return [updated, ...prev];
    });
  };

  // Submit to owner queue
  const handleSaveToOwnerQueue = (rpt: StaffReport) => {
    handleUpdateReport(rpt);
    syncService.saveReport(rpt).catch((err) => console.warn('Cloud sync report error:', err));
  };

  // Owner approval action
  const handleApproveReport = (reportId: string, reviewData: Partial<StaffReport>) => {
    setReports((prev) =>
      prev.map((r) => {
        if (r.id === reportId) {
          const updated = { ...r, ...reviewData, isReviewed: true };
          if (activeReport.id === reportId) {
            setActiveReport(updated);
          }
          return updated;
        }
        return r;
      })
    );
  };

  // Count items with stock <= 3 for the top alert badge
  const lowStockCount = inventory.filter((item) => item.stockQuantity <= 3).length;

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 font-sans text-stone-900 selection:bg-amber-100 selection:text-amber-950">
      {/* Top Header */}
      <Header
        currentView={currentView}
        onNavigate={setCurrentView}
        activeBusiness={activeBusiness}
        onSwitchBusiness={(biz) => {
          setActiveBusiness(biz);
          if (biz === 'poultry') {
            setCurrentView('poultry');
          } else {
            setCurrentView('shopbook');
          }
        }}
        lowStockCount={lowStockCount}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
      />

      {/* Main App Content Viewport */}
      <main className={activeBusiness === 'biashara' ? 'flex-1 w-full' : 'flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6'}>
        {/* VIEW: BIASHARABASE.COM DIGITAL PRODUCT GUIDE */}
        {activeBusiness === 'biashara' && (
          <BiasharaBaseApp
            onBackToApp={() => {
              setActiveBusiness('poultry');
              setCurrentView('poultry');
            }}
          />
        )}

        {/* VIEW 0: BLESSED POULTRY FARM MANAGEMENT (TANZANIA) */}
        {activeBusiness === 'poultry' && (
          <ChickenManagementApp
            batches={poultryBatches}
            vaccinations={poultryVaccinations}
            feeds={poultryFeeds}
            mortalities={poultryMortalities}
            expenses={poultryExpenses}
            sales={poultrySales}
            onAddBatch={handleAddPoultryBatch}
            onUpdateBatch={handleUpdatePoultryBatch}
            onAddVaccination={handleAddPoultryVaccination}
            onUpdateVaccination={handleUpdatePoultryVaccination}
            onAddFeed={handleAddPoultryFeed}
            onAddMortality={handleAddPoultryMortality}
            onAddExpense={handleAddPoultryExpense}
            onAddSale={handleAddPoultrySale}
            onUpdateSale={handleUpdatePoultrySale}
            onResetToTanzaniaData={handleResetToTanzaniaData}
            cloudConnected={cloudConnected}
            onManualSyncToCloud={handleManualSyncPoultryToCloud}
            onRestorePoultryBackup={handleRestorePoultryBackup}
          />
        )}

        {/* SALON SECTION VIEWS (Active when activeBusiness === 'salon') */}
        {activeBusiness === 'salon' && currentView === 'shopbook' && (
          <SalonShopBook
            sales={sales}
            expenses={expenses}
            inventory={inventory}
            staffList={staffList}
            handovers={handovers}
            onAddSale={handleAddSale}
            onAddExpense={handleAddExpense}
            onSaveHandover={handleSaveHandover}
          />
        )}

        {/* VIEW 2: INVENTORY & STOCK ALERTS (< 3 ALERT) */}
        {currentView === 'inventory' && (
          <StockAlertsManager
            inventory={inventory}
            onUpdateInventory={setInventory}
          />
        )}

        {/* VIEW 3: CLIENT SALON CATALOG & SERVICES */}
        {currentView === 'salon' && (
          <ClientSalonView
            onOpenStaffForm={() => setCurrentView('form')}
            onOpenOwnerPortal={() => setCurrentView('owner')}
          />
        )}

        {/* VIEW 4: STAFF REPORT FORM ENTRY */}
        {currentView === 'form' && (
          <StaffReportForm
            report={activeReport}
            staffList={staffList}
            onUpdateReport={handleUpdateReport}
            onSaveToOwnerQueue={handleSaveToOwnerQueue}
            onSwitchToPreview={() => setCurrentView('preview')}
            isOwner={false}
          />
        )}

        {/* VIEW 5: 3-PAGE OFFICIAL DOCUMENT PREVIEW */}
        {currentView === 'preview' && (
          <ReportDocumentPreview
            report={activeReport}
            onEdit={() => setCurrentView('form')}
            onApproveByOwner={() => {
              handleApproveReport(activeReport.id, {
                reviewerComments: 'Verified and approved by salon owner.',
                performanceRating: 'Excellent',
                actionPoints: 'Maintain high retail cross-sales and exemplary client care.',
                reviewerName: 'Tinez Kapuya',
                reviewerSignature: 'Tinez Kapuya (Salon Owner & Director)',
                reviewDate: new Date().toISOString().split('T')[0]
              });
            }}
            isOwner={true}
          />
        )}

        {/* VIEW 6: OWNER PRIVATE SECTION (TINEZ KAPUYA) */}
        {currentView === 'owner' && (
          <OwnerPortal
            reports={reports}
            staffList={staffList}
            vaultState={vaultState}
            sales={sales}
            expenses={expenses}
            handovers={handovers}
            inventory={inventory}
            cloudConnected={cloudConnected}
            onRestoreBackup={handleRestoreBackup}
            onUpdateVault={setVaultState}
            onUpdateStaffList={setStaffList}
            onOpenReportPreview={(rpt) => {
              setActiveReport(rpt);
              setCurrentView('preview');
            }}
            onEditReport={(rpt) => {
              setActiveReport(rpt);
              setCurrentView('form');
            }}
            onApproveReport={handleApproveReport}
            onOpenInstallModal={() => setIsInstallModalOpen(true)}
          />
        )}
      </main>

      {/* iPhone-Optimized Mobile Sticky Quick Navigation Bar (Safe-Area Bottom) */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-stone-200 px-3 pt-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] no-print flex items-center justify-around text-[10px] font-bold text-stone-600 shadow-lg">
        {activeBusiness === 'biashara' ? (
          <>
            <button
              onClick={() => {
                setActiveBusiness('biashara');
                setCurrentView('biashara');
              }}
              className="flex flex-col items-center gap-0.5 text-black font-archivo font-black"
            >
              <div className="w-5 h-5 rounded-md bg-black text-[#D2F803] flex items-center justify-center text-[11px]">
                B
              </div>
              <span className="text-[9px] uppercase tracking-wider">Guide</span>
            </button>

            <button
              onClick={() => {
                setActiveBusiness('poultry');
                setCurrentView('poultry');
              }}
              className="flex flex-col items-center gap-0.5 text-stone-600 hover:text-stone-900"
            >
              <Bird className="w-4 h-4 text-amber-600" />
              <span>Poultry</span>
            </button>

            <button
              onClick={() => {
                setActiveBusiness('salon');
                setCurrentView('shopbook');
              }}
              className="flex flex-col items-center gap-0.5 text-stone-600 hover:text-stone-900"
            >
              <Scissors className="w-4 h-4 text-emerald-800" />
              <span>Salon</span>
            </button>

            <button
              onClick={() => setIsInstallModalOpen(true)}
              className="flex flex-col items-center gap-0.5 text-stone-600 hover:text-stone-900"
              title="Install on iPhone / QR Code"
            >
              <QrCode className="w-4 h-4 text-stone-700" />
              <span>QR / App</span>
            </button>
          </>
        ) : activeBusiness === 'poultry' ? (
          <>
            <button
              onClick={() => {
                setActiveBusiness('poultry');
                setCurrentView('poultry');
              }}
              className="flex flex-col items-center gap-0.5 text-amber-900 font-bold"
            >
              <Bird className="w-4 h-4 text-amber-600" />
              <span>Shamba (Farm)</span>
            </button>

            <a
              href="tel:0757895896"
              className="flex flex-col items-center gap-0.5 text-emerald-800 font-bold"
              title="Piga Simu 0757 895 896"
            >
              <div className="w-5 h-5 rounded-full bg-emerald-100 flex items-center justify-center">
                <span className="text-[10px]">📞</span>
              </div>
              <span>0757 895 896</span>
            </a>

            <button
              onClick={() => {
                setActiveBusiness('biashara');
                setCurrentView('biashara');
              }}
              className="flex flex-col items-center gap-0.5 text-stone-600 hover:text-stone-900"
            >
              <BookMarked className="w-4 h-4 text-[#D2F803] bg-black rounded p-0.5" />
              <span>Biashara</span>
            </button>

            <button
              onClick={() => {
                setActiveBusiness('salon');
                setCurrentView('shopbook');
              }}
              className="flex flex-col items-center gap-0.5 text-stone-600 hover:text-stone-900"
            >
              <Scissors className="w-4 h-4 text-emerald-800" />
              <span>Salon</span>
            </button>
          </>
        ) : (
          <>
            <button
              onClick={() => {
                setActiveBusiness('salon');
                setCurrentView('shopbook');
              }}
              className="flex flex-col items-center gap-0.5 text-emerald-900 font-bold"
            >
              <BookOpen className="w-4 h-4 text-emerald-800" />
              <span>Salon Book</span>
            </button>

            <button
              onClick={() => {
                setActiveBusiness('biashara');
                setCurrentView('biashara');
              }}
              className="flex flex-col items-center gap-0.5 text-stone-600 hover:text-stone-900"
            >
              <BookMarked className="w-4 h-4 text-[#D2F803] bg-black rounded p-0.5" />
              <span>Biashara</span>
            </button>

            <button
              onClick={() => {
                setActiveBusiness('poultry');
                setCurrentView('poultry');
              }}
              className="flex flex-col items-center gap-0.5 text-stone-600 hover:text-stone-900"
            >
              <Bird className="w-4 h-4 text-amber-600" />
              <span>Poultry</span>
            </button>

            <button
              onClick={() => {
                setActiveBusiness('salon');
                setCurrentView('owner');
              }}
              className="flex flex-col items-center gap-0.5 text-stone-600 hover:text-stone-900"
            >
              <Lock className="w-4 h-4 text-amber-600" />
              <span>Owner PIN</span>
            </button>
          </>
        )}
      </div>

      {/* Official Footer */}
      <footer className="bg-stone-900 text-stone-400 text-xs py-8 px-4 sm:px-6 border-t border-stone-800 no-print">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            {activeBusiness === 'biashara' ? (
              <div className="w-10 h-10 rounded-xl bg-black text-[#D2F803] font-archivo font-black text-lg flex items-center justify-center border-2 border-[#D2F803] shrink-0">
                B
              </div>
            ) : activeBusiness === 'poultry' ? (
              <img
                src="/blessed_poultry_logo.jpg"
                alt="Blessed Poultry Logo"
                className="h-10 w-10 rounded-full object-cover border border-amber-300 shrink-0"
                referrerPolicy="no-referrer"
              />
            ) : (
              <img
                src="/bareglow_logo_trimmed.png"
                alt="Bareglow Logo"
                className="h-9 object-contain brightness-110 shrink-0"
                referrerPolicy="no-referrer"
              />
            )}
            <div>
              <p className="font-bold text-white tracking-wide font-serif text-sm">
                {activeBusiness === 'biashara'
                  ? 'BiasharaBase · biasharabase.com'
                  : activeBusiness === 'poultry'
                  ? 'Blessed Poultry · Chicken Farm Management'
                  : 'Bareglow Book and Management'}
              </p>
              <p className="text-[11px] text-stone-400">
                {activeBusiness === 'biashara'
                  ? 'Digital Commerce Guide · No-Reels Social Selling System · @biasharabase'
                  : activeBusiness === 'poultry'
                  ? 'Poultry Livestock, Feed, Health & Financial Records (TZS)'
                  : `Owner & Founder: Tinez Kapuya · ${SALON_INFO.address}`}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-[11px]">
            <button
              onClick={() => {
                setActiveBusiness('biashara');
                setCurrentView('biashara');
              }}
              className="text-[#D2F803] hover:underline font-archivo font-bold transition-colors cursor-pointer"
            >
              📖 BiasharaBase Guide
            </button>
            <button
              onClick={() => {
                setActiveBusiness('poultry');
                setCurrentView('poultry');
              }}
              className="text-amber-400 hover:underline font-semibold transition-colors cursor-pointer"
            >
              🐔 Blessed Poultry (TZS)
            </button>
            <button
              onClick={() => {
                setActiveBusiness('salon');
                setCurrentView('shopbook');
              }}
              className="text-emerald-400 hover:underline font-semibold transition-colors cursor-pointer"
            >
              💇‍♀️ Bareglow Salon
            </button>
            <button
              onClick={() => setIsInstallModalOpen(true)}
              className="text-stone-300 hover:text-white font-semibold transition-colors underline cursor-pointer"
            >
              Get Phone App / Scan QR
            </button>
          </div>
        </div>
      </footer>

      {/* PWA Phone Installation & Reception QR Code Modal */}
      <AppInstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
      />
    </div>
  );
}
